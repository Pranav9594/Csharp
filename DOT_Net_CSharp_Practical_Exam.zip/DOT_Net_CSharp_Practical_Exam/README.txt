DOT NET (C#) PRACTICAL EXAM COLLECTION - READ ME
=================================================
Lab on DOT Net Programming Using C# (BCA Sem V, Course 502) - Visual Studio 2010, C# 4.0, .NET Framework 4.0

FOLDERS
  01_Journal_Programs          18 journal programs (Q01-Q18). Q15 is a Windows Forms project folder.
  02_Simplified_ZIP_Programs   101 console programs from your ZIP files + the WindowsFormsApplication10 project.
  03_Important_Extra_Programs  42 extra practice programs (EXTRA01-EXTRA42) + SQL helper script.
  04_Question_List             Question_List.txt (all questions with file names).
  05_Revision_Material         Revision_Topicwise.txt.
  06_Original_Backup           Your original uploaded files, untouched.
  Practical_Exam_Program_Collection.pdf   (same folder as this file when you download the PDF)

FILE NAMING
  Q01_...cs     journal programs
  CC_pNN_...cs  from "C# Codes" folder (C__Codes.zip), original file pNN.cs
  CD_pNN_...cs  from Codes.zip, original file pNN.cs (box, del1, del2, eventex, threadex keep their names)
  ADO_pNN_...cs from Codes.zip / ado_netprograms
  EXTRAnn_...cs additional practice programs

IMPORTANT
  * The ZIP files contained no question text. The questions for ZIP programs were written from what each program does.
  * Every console program was compiled and run with Mono (C# 4 mode) - NOT with Visual Studio 2010 itself.
  * Programs needing SQL Server or a GUI were only compiled, not run. See the PDF last section and the final report.
