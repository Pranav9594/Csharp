Original uploaded files, copied byte-for-byte and never modified.
BCA_Sem_V_DotNet_Practical_Assignment.zip = journal questions and codes (18 programs)
C__Codes.zip = 'C# Codes' reference programs (43 files)
Codes.zip = reference programs (46 files) + ado_netprograms (12 files + 2 BMP screenshots)
WindowsFormsApplication10.zip = Windows Forms + ADO.NET project
The two PNG files are the syllabus pages.
