// ======================================================================
// Question No. : EXTRA38
// Question     : Write a Windows Forms application using RadioButton, CheckBox, ListBox and ComboBox controls.
// Topic        : Windows Forms - common controls
// File         : EXTRA38_WinForms_Common_Controls.cs
// Source       : Additional practice program (not from journal or ZIP)
// Type         : Windows Forms application (create a Windows Forms project, or a Console project
//                and change Output type to Windows Application; add references System.Windows.Forms and System.Drawing).
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Drawing;
using System.Windows.Forms;

class ControlsForm : Form
{
    RadioButton rbMale, rbFemale;
    CheckBox cbReading, cbMusic;
    ComboBox cmbCity;
    ListBox lstCourse;
    Button btnShow;

    public ControlsForm()
    {
        this.Text = "Common Controls";
        this.Size = new Size(320, 360);

        rbMale = new RadioButton();
        rbMale.Text = "Male";
        rbMale.Location = new Point(20, 20);
        rbFemale = new RadioButton();
        rbFemale.Text = "Female";
        rbFemale.Location = new Point(120, 20);

        cbReading = new CheckBox();
        cbReading.Text = "Reading";
        cbReading.Location = new Point(20, 60);
        cbMusic = new CheckBox();
        cbMusic.Text = "Music";
        cbMusic.Location = new Point(120, 60);

        cmbCity = new ComboBox();
        cmbCity.Location = new Point(20, 100);
        cmbCity.Items.Add("Mumbai");
        cmbCity.Items.Add("Pune");
        cmbCity.Items.Add("Nashik");

        lstCourse = new ListBox();
        lstCourse.Location = new Point(20, 140);
        lstCourse.Size = new Size(120, 60);
        lstCourse.Items.Add("BCA");
        lstCourse.Items.Add("BBA");
        lstCourse.Items.Add("MCA");

        btnShow = new Button();
        btnShow.Text = "Show";
        btnShow.Location = new Point(20, 220);
        btnShow.Click += new EventHandler(btnShow_Click);

        this.Controls.Add(rbMale);
        this.Controls.Add(rbFemale);
        this.Controls.Add(cbReading);
        this.Controls.Add(cbMusic);
        this.Controls.Add(cmbCity);
        this.Controls.Add(lstCourse);
        this.Controls.Add(btnShow);
    }

    void btnShow_Click(object sender, EventArgs e)
    {
        string msg = "";
        if (rbMale.Checked) msg += "Gender : Male\n";
        if (rbFemale.Checked) msg += "Gender : Female\n";
        if (cbReading.Checked) msg += "Hobby : Reading\n";
        if (cbMusic.Checked) msg += "Hobby : Music\n";
        msg += "City : " + cmbCity.Text + "\n";
        if (lstCourse.SelectedItem != null) msg += "Course : " + lstCourse.SelectedItem;
        MessageBox.Show(msg);
    }

    [STAThread]
    static void Main()
    {
        Application.Run(new ControlsForm());
    }
}
