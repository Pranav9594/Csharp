// ======================================================================
// Question No. : EXTRA11
// Question     : Write a C# program to read n numbers in an array and display the largest, smallest and the sorted array.
// Topic        : Arrays
// File         : EXTRA11_Array_Largest_Smallest_Sort.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class ArrayDemo
{
    static void Main()
    {
        int n, i;
        Console.Write("Enter number of elements: ");
        n = Convert.ToInt32(Console.ReadLine());
        int[] a = new int[n];

        for (i = 0; i < n; i++)
        {
            Console.Write("Enter element " + (i + 1) + ": ");
            a[i] = Convert.ToInt32(Console.ReadLine());
        }

        int max = a[0], min = a[0];
        for (i = 1; i < n; i++)
        {
            if (a[i] > max) max = a[i];
            if (a[i] < min) min = a[i];
        }
        Console.WriteLine("Largest  = " + max);
        Console.WriteLine("Smallest = " + min);

        Array.Sort(a);
        Console.Write("Sorted array: ");
        for (i = 0; i < n; i++)
        {
            Console.Write(a[i] + " ");
        }
        Console.WriteLine();
    }
}
