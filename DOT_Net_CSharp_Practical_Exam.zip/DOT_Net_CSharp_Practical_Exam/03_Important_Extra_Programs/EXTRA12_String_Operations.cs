// ======================================================================
// Question No. : EXTRA12
// Question     : Write a C# program to perform common string operations.
// Topic        : Strings
// File         : EXTRA12_String_Operations.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class StringDemo
{
    static void Main()
    {
        string s = "  Welcome to C# Programming  ";
        string t = s.Trim();

        Console.WriteLine("Original   : [" + s + "]");
        Console.WriteLine("Trimmed    : [" + t + "]");
        Console.WriteLine("Length     : " + t.Length);
        Console.WriteLine("Upper      : " + t.ToUpper());
        Console.WriteLine("Lower      : " + t.ToLower());
        Console.WriteLine("Substring  : " + t.Substring(0, 7));
        Console.WriteLine("IndexOf C# : " + t.IndexOf("C#"));
        Console.WriteLine("Replace    : " + t.Replace("C#", "Dot Net"));
        Console.WriteLine("Contains   : " + t.Contains("Welcome"));
        Console.WriteLine("Compare    : " + string.Compare("apple", "banana"));
        Console.WriteLine("Concat     : " + string.Concat("Hello", " ", "World"));

        string[] words = t.Split(' ');
        Console.WriteLine("Words      : " + words.Length);
        for (int i = 0; i < words.Length; i++)
        {
            Console.WriteLine(words[i]);
        }
    }
}
