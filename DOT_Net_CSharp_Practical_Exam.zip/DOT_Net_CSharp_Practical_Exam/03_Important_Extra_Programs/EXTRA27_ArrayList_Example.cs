// ======================================================================
// Question No. : EXTRA27
// Question     : Write a C# program to demonstrate the ArrayList collection class.
// Topic        : Collections - ArrayList
// File         : EXTRA27_ArrayList_Example.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Collections;

class ArrayListDemo
{
    static void Main()
    {
        ArrayList list = new ArrayList();
        list.Add(30);
        list.Add(10);
        list.Add(20);
        list.Insert(1, 99);
        Console.WriteLine("Count = " + list.Count);

        list.Remove(10);
        Console.WriteLine("Contains 20 : " + list.Contains(20));

        list.Sort();
        Console.WriteLine("After sorting:");
        foreach (int x in list)
        {
            Console.WriteLine(x);
        }
    }
}
