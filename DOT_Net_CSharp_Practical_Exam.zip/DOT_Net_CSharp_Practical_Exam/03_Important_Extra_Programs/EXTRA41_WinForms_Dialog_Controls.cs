// ======================================================================
// Question No. : EXTRA41
// Question     : Write a Windows Forms application that uses OpenFileDialog and ColorDialog.
// Topic        : Windows Forms - dialog controls
// File         : EXTRA41_WinForms_Dialog_Controls.cs
// Source       : Additional practice program (not from journal or ZIP)
// Type         : Windows Forms application (create a Windows Forms project, or a Console project
//                and change Output type to Windows Application; add references System.Windows.Forms and System.Drawing).
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Drawing;
using System.Windows.Forms;

class DialogForm : Form
{
    Label lbl;
    Button btnOpen, btnColor;

    public DialogForm()
    {
        this.Text = "Dialog Controls";
        this.Size = new Size(350, 200);

        btnOpen = new Button();
        btnOpen.Text = "Open File";
        btnOpen.Location = new Point(20, 20);
        btnOpen.Click += new EventHandler(btnOpen_Click);

        btnColor = new Button();
        btnColor.Text = "Change Colour";
        btnColor.Location = new Point(120, 20);
        btnColor.Click += new EventHandler(btnColor_Click);

        lbl = new Label();
        lbl.Location = new Point(20, 70);
        lbl.AutoSize = true;
        lbl.Text = "Selected file will be shown here";

        this.Controls.Add(btnOpen);
        this.Controls.Add(btnColor);
        this.Controls.Add(lbl);
    }

    void btnOpen_Click(object sender, EventArgs e)
    {
        OpenFileDialog ofd = new OpenFileDialog();
        if (ofd.ShowDialog() == DialogResult.OK)
        {
            lbl.Text = ofd.FileName;
        }
    }

    void btnColor_Click(object sender, EventArgs e)
    {
        ColorDialog cd = new ColorDialog();
        if (cd.ShowDialog() == DialogResult.OK)
        {
            this.BackColor = cd.Color;
        }
    }

    [STAThread]
    static void Main()
    {
        Application.Run(new DialogForm());
    }
}
