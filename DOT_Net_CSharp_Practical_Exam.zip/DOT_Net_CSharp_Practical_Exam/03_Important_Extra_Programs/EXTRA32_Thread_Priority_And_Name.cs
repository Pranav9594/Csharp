// ======================================================================
// Question No. : EXTRA32
// Question     : Write a C# program to create two threads, give them names and priorities and run them.
// Topic        : Multithreading - thread class and priority
// File         : EXTRA32_Thread_Priority_And_Name.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Threading;

class PriorityDemo
{
    static void Work()
    {
        Console.WriteLine(Thread.CurrentThread.Name + " running with priority " + Thread.CurrentThread.Priority);
    }

    static void Main()
    {
        Thread t1 = new Thread(new ThreadStart(Work));
        Thread t2 = new Thread(new ThreadStart(Work));

        t1.Name = "Thread-1";
        t2.Name = "Thread-2";
        t1.Priority = ThreadPriority.Highest;
        t2.Priority = ThreadPriority.Lowest;

        t1.Start();
        t1.Join();          // Join is used here so the output order is fixed
        t2.Start();
        t2.Join();
        Console.WriteLine("Main finished");
    }
}
