// ======================================================================
// Question No. : EXTRA40
// Question     : Write a Windows Forms MDI application with a parent form and child forms opened from a menu.
// Topic        : Windows Forms - SDI and MDI
// File         : EXTRA40_WinForms_MDI_Application.cs
// Source       : Additional practice program (not from journal or ZIP)
// Type         : Windows Forms application (create a Windows Forms project, or a Console project
//                and change Output type to Windows Application; add references System.Windows.Forms and System.Drawing).
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Drawing;
using System.Windows.Forms;

class ParentForm : Form
{
    int count = 0;

    public ParentForm()
    {
        this.Text = "MDI Parent";
        this.Size = new Size(500, 400);
        this.IsMdiContainer = true;

        MenuStrip ms = new MenuStrip();
        ToolStripMenuItem window = new ToolStripMenuItem("Window");
        ToolStripMenuItem newChild = new ToolStripMenuItem("New Child");
        ToolStripMenuItem cascade = new ToolStripMenuItem("Cascade");
        newChild.Click += new EventHandler(newChild_Click);
        cascade.Click += new EventHandler(cascade_Click);
        window.DropDownItems.Add(newChild);
        window.DropDownItems.Add(cascade);
        ms.Items.Add(window);

        this.Controls.Add(ms);
        this.MainMenuStrip = ms;
    }

    void newChild_Click(object sender, EventArgs e)
    {
        count++;
        Form child = new Form();
        child.Text = "Child " + count;
        child.MdiParent = this;
        child.Show();
    }

    void cascade_Click(object sender, EventArgs e)
    {
        this.LayoutMdi(MdiLayout.Cascade);
    }

    [STAThread]
    static void Main()
    {
        Application.Run(new ParentForm());
    }
}
