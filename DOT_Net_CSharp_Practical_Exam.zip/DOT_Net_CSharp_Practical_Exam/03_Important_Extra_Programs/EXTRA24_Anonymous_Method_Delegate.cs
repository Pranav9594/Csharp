// ======================================================================
// Question No. : EXTRA24
// Question     : Write a C# program to demonstrate an anonymous method with a delegate.
// Topic        : Delegates - anonymous methods
// File         : EXTRA24_Anonymous_Method_Delegate.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

delegate int Calculate(int x, int y);

class AnonymousDemo
{
    static void Main()
    {
        Calculate add = delegate(int x, int y)
        {
            return x + y;
        };

        Calculate mul = delegate(int x, int y)
        {
            return x * y;
        };

        Console.WriteLine("Addition       = " + add(10, 5));
        Console.WriteLine("Multiplication = " + mul(10, 5));
    }
}
