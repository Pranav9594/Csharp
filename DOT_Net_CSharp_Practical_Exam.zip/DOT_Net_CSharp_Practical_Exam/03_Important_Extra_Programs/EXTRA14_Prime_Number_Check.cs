// ======================================================================
// Question No. : EXTRA14
// Question     : Write a C# program to check whether a number is prime.
// Topic        : Control statements
// File         : EXTRA14_Prime_Number_Check.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class PrimeDemo
{
    static void Main()
    {
        int n, i;
        bool prime = true;

        Console.Write("Enter a number: ");
        n = Convert.ToInt32(Console.ReadLine());

        if (n < 2)
        {
            prime = false;
        }
        for (i = 2; i <= n / 2; i++)
        {
            if (n % i == 0)
            {
                prime = false;
                break;
            }
        }

        if (prime)
            Console.WriteLine(n + " is a prime number");
        else
            Console.WriteLine(n + " is not a prime number");
    }
}
