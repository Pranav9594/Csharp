// ======================================================================
// Question No. : EXTRA35
// Question     : Write a C# program to create a DataSet with two tables (Course, Student), relate them using a DataRelation and display the students of each course.
// Topic        : ADO.NET - DataSet and DataRelation
// File         : EXTRA35_DataSet_DataRelation_No_Database.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;

class RelationDemo
{
    static void Main()
    {
        DataSet ds = new DataSet();

        DataTable course = new DataTable("Course");
        course.Columns.Add("C_ID", typeof(int));
        course.Columns.Add("C_Name", typeof(string));
        course.Rows.Add(1, "BCA");
        course.Rows.Add(2, "BBA");

        DataTable student = new DataTable("Student");
        student.Columns.Add("RollNo", typeof(int));
        student.Columns.Add("S_Name", typeof(string));
        student.Columns.Add("C_ID", typeof(int));
        student.Rows.Add(101, "Rahul", 1);
        student.Rows.Add(102, "Priya", 1);
        student.Rows.Add(103, "Amit", 2);

        ds.Tables.Add(course);
        ds.Tables.Add(student);

        DataRelation rel = new DataRelation("CourseStudent", course.Columns["C_ID"], student.Columns["C_ID"]);
        ds.Relations.Add(rel);

        foreach (DataRow c in course.Rows)
        {
            Console.WriteLine("Course : " + c["C_Name"]);
            foreach (DataRow s in c.GetChildRows(rel))
            {
                Console.WriteLine("    " + s["RollNo"] + "  " + s["S_Name"]);
            }
        }
    }
}
