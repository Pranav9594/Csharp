-- Helper script (written for this collection; NOT tested on SQL Server).
-- Run it inside the database used by the ADO.NET programs (Database1.mdf).
-- The original college programs use these column names in different files:
--   Select/Insert programs use column positions, p9 uses 'empno', p10 uses 'empno' and 'ename',
--   p6 uses 'Emp_No'.  Create the table with the names your program needs.
CREATE TABLE Employee
(
    empno   int          NOT NULL PRIMARY KEY,
    ename   varchar(50),
    salary  float
);

INSERT INTO Employee VALUES (1, 'Amit', 30000);
INSERT INTO Employee VALUES (2, 'Neha', 35000);
INSERT INTO Employee VALUES (3, 'Raj',  40000);

-- Stored procedure used by ADO_p12 (Stored_Procedure)
-- (the original program connects to database 'test' with user sa)
CREATE PROCEDURE spAddEmployee
    @id  int,
    @nm  varchar(50),
    @sal float
AS
BEGIN
    INSERT INTO Employee VALUES (@id, @nm, @sal);
END
