// ======================================================================
// Question No. : EXTRA16
// Question     : Write a C# program to multiply two 2 x 2 matrices.
// Topic        : Arrays
// File         : EXTRA16_Matrix_Multiplication.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class MatrixMul
{
    static void Main()
    {
        int[,] a = { { 1, 2 }, { 3, 4 } };
        int[,] b = { { 5, 6 }, { 7, 8 } };
        int[,] c = new int[2, 2];
        int i, j, k;

        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 2; j++)
            {
                c[i, j] = 0;
                for (k = 0; k < 2; k++)
                {
                    c[i, j] = c[i, j] + a[i, k] * b[k, j];
                }
            }
        }

        Console.WriteLine("Product matrix:");
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 2; j++)
            {
                Console.Write(c[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}
