// ======================================================================
// Question No. : EXTRA15
// Question     : Write a C# program to find the factorial of a number and display the Fibonacci series.
// Topic        : Control statements
// File         : EXTRA15_Factorial_And_Fibonacci.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class FactFib
{
    static void Main()
    {
        int n, i;
        long fact = 1;

        Console.Write("Enter a number: ");
        n = Convert.ToInt32(Console.ReadLine());

        for (i = 1; i <= n; i++)
        {
            fact = fact * i;
        }
        Console.WriteLine("Factorial of " + n + " = " + fact);

        int a = 0, b = 1, c;
        Console.Write("Fibonacci series: ");
        for (i = 1; i <= n; i++)
        {
            Console.Write(a + " ");
            c = a + b;
            a = b;
            b = c;
        }
        Console.WriteLine();
    }
}
