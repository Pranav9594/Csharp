// ======================================================================
// Question No. : EXTRA08
// Question     : Write a C# program to demonstrate a static constructor, a static method and a static class.
// Topic        : Static members
// File         : EXTRA08_Static_Constructor_Static_Class.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Bank
{
    public static double rate;

    static Bank()                       // runs once automatically
    {
        rate = 6.5;
        Console.WriteLine("Static constructor called");
    }

    public static void ShowRate()
    {
        Console.WriteLine("Interest rate = " + rate);
    }
}

static class MathHelper
{
    public static int Square(int x)
    {
        return x * x;
    }
}

class StaticDemo
{
    static void Main()
    {
        Bank.ShowRate();
        Console.WriteLine("Square of 7 = " + MathHelper.Square(7));
    }
}
