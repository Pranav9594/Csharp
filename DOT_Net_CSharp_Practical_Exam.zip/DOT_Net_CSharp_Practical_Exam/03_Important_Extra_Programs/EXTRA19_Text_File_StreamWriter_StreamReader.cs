// ======================================================================
// Question No. : EXTRA19
// Question     : Write a C# program to write text to a file using StreamWriter and read it back using StreamReader.
// Topic        : I/O - text stream
// File         : EXTRA19_Text_File_StreamWriter_StreamReader.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.IO;

class TextFileDemo
{
    static void Main()
    {
        StreamWriter sw = new StreamWriter("student.txt");
        sw.WriteLine("Rahul Shah");
        sw.WriteLine("Priya Mehta");
        sw.WriteLine("Amit Patil");
        sw.Close();
        Console.WriteLine("File written");

        StreamReader sr = new StreamReader("student.txt");
        string line;
        while ((line = sr.ReadLine()) != null)
        {
            Console.WriteLine(line);
        }
        sr.Close();
    }
}
