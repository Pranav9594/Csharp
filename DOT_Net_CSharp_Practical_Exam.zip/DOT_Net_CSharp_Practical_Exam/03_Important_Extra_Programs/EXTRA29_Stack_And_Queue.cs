// ======================================================================
// Question No. : EXTRA29
// Question     : Write a C# program to demonstrate the Stack (LIFO) and Queue (FIFO) collection classes.
// Topic        : Collections - Stack and Queue
// File         : EXTRA29_Stack_And_Queue.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Collections;

class StackQueueDemo
{
    static void Main()
    {
        Stack s = new Stack();
        s.Push(10);
        s.Push(20);
        s.Push(30);
        Console.WriteLine("Stack Peek = " + s.Peek());
        Console.WriteLine("Stack Pop  = " + s.Pop());
        Console.WriteLine("Stack Pop  = " + s.Pop());
        Console.WriteLine("Stack Count = " + s.Count);

        Queue q = new Queue();
        q.Enqueue("A");
        q.Enqueue("B");
        q.Enqueue("C");
        Console.WriteLine("Queue Peek    = " + q.Peek());
        Console.WriteLine("Queue Dequeue = " + q.Dequeue());
        Console.WriteLine("Queue Dequeue = " + q.Dequeue());
        Console.WriteLine("Queue Count   = " + q.Count);
    }
}
