// ======================================================================
// Question No. : EXTRA28
// Question     : Write a C# program to demonstrate the Hashtable collection class.
// Topic        : Collections - Hashtable
// File         : EXTRA28_Hashtable_Example.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Collections;

class HashtableDemo
{
    static void Main()
    {
        Hashtable ht = new Hashtable();
        ht.Add(101, "Rahul");
        ht.Add(102, "Priya");
        ht.Add(103, "Amit");

        Console.WriteLine("Name of 102 : " + ht[102]);
        Console.WriteLine("Contains key 103 : " + ht.ContainsKey(103));
        ht.Remove(101);
        Console.WriteLine("Count = " + ht.Count);

        Console.WriteLine("Keys and values:");
        foreach (DictionaryEntry d in ht)
        {
            Console.WriteLine(d.Key + " - " + d.Value);
        }
    }
}
