// ======================================================================
// Question No. : EXTRA07
// Question     : Write a C# program to demonstrate the sealed keyword (a valid program).
// Topic        : Sealed keyword
// File         : EXTRA07_Sealed_Class_And_Sealed_Method.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Base
{
    public virtual void Show()
    {
        Console.WriteLine("Show of Base");
    }
}

class Middle : Base
{
    public sealed override void Show()      // cannot be overridden further
    {
        Console.WriteLine("Show of Middle (sealed method)");
    }
}

sealed class Final : Middle                 // cannot be inherited
{
    public void Hello()
    {
        Console.WriteLine("Hello from sealed class");
    }
}

class SealedDemo
{
    static void Main()
    {
        Final f = new Final();
        f.Show();
        f.Hello();
    }
}
