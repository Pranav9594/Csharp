// ======================================================================
// Question No. : EXTRA01
// Question     : Write a C# program to demonstrate an enum (enumeration).
// Topic        : Enum and constant
// File         : EXTRA01_Enum_Example.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

enum Days { Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday }

class EnumDemo
{
    static void Main()
    {
        Days d = Days.Wednesday;
        Console.WriteLine("Day name  : " + d);
        Console.WriteLine("Day value : " + (int)d);

        switch (d)
        {
            case Days.Sunday:
                Console.WriteLine("Holiday");
                break;
            case Days.Wednesday:
                Console.WriteLine("Mid week");
                break;
            default:
                Console.WriteLine("Working day");
                break;
        }

        Console.WriteLine("All days:");
        foreach (string s in Enum.GetNames(typeof(Days)))
        {
            Console.WriteLine(s);
        }
    }
}
