// ======================================================================
// Question No. : EXTRA42
// Question     : Write a Windows Forms application showing a master-detail form: selecting a course in the top grid shows its students in the bottom grid (STUDENT database).
// Topic        : ADO.NET - master detail form
// File         : EXTRA42_WinForms_Master_Detail_Form.cs
// Source       : Additional practice program (not from journal or ZIP)
// Type         : Windows Forms application (create a Windows Forms project, or a Console project
//                and change Output type to Windows Application; add references System.Windows.Forms and System.Drawing).
// Requires     : SQL Server Express and the STUDENT database (see 01_Journal_Programs/Q15 SETUP).
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

class MasterDetailForm : Form
{
    DataGridView gridMaster, gridDetail;

    public MasterDetailForm()
    {
        this.Text = "Master Detail";
        this.Size = new Size(500, 450);

        gridMaster = new DataGridView();
        gridMaster.Location = new Point(10, 10);
        gridMaster.Size = new Size(460, 160);

        gridDetail = new DataGridView();
        gridDetail.Location = new Point(10, 190);
        gridDetail.Size = new Size(460, 200);

        this.Controls.Add(gridMaster);
        this.Controls.Add(gridDetail);
        this.Load += new EventHandler(MasterDetailForm_Load);
    }

    void MasterDetailForm_Load(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\STUDENT.mdf;Integrated Security=True;User Instance=True");

        DataSet ds = new DataSet();
        SqlDataAdapter da1 = new SqlDataAdapter("select * from Course", cn);
        da1.Fill(ds, "Course");
        SqlDataAdapter da2 = new SqlDataAdapter("select * from Student", cn);
        da2.Fill(ds, "Student");

        DataRelation rel = new DataRelation("CourseStudent", ds.Tables["Course"].Columns["C_ID"], ds.Tables["Student"].Columns["C_ID"]);
        ds.Relations.Add(rel);

        gridMaster.DataSource = ds;
        gridMaster.DataMember = "Course";

        gridDetail.DataSource = ds;
        gridDetail.DataMember = "Course.CourseStudent";
    }

    [STAThread]
    static void Main()
    {
        Application.Run(new MasterDetailForm());
    }
}
