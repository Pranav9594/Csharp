// ======================================================================
// Question No. : EXTRA10
// Question     : Write a C# program to find the area of a square, rectangle and circle using method overloading.
// Topic        : Method overloading
// File         : EXTRA10_Method_Overloading_Area.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Area
{
    public double Calc(double side)
    {
        return side * side;                 // square
    }

    public double Calc(double l, double b)
    {
        return l * b;                       // rectangle
    }

    public double Calc(double r, int dummy)
    {
        return 3.14 * r * r;                // circle
    }
}

class OverloadDemo
{
    static void Main()
    {
        Area a = new Area();
        Console.WriteLine("Square area    = " + a.Calc(4.0));
        Console.WriteLine("Rectangle area = " + a.Calc(4.0, 5.0));
        Console.WriteLine("Circle area    = " + a.Calc(3.0, 0));
    }
}
