// ======================================================================
// Question No. : EXTRA33
// Question     : Write a C# program to show thread synchronization using the lock statement.
// Topic        : Multithreading - synchronization
// File         : EXTRA33_Thread_Synchronization_Lock.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Threading;

class SyncDemo
{
    static int count = 0;
    static object locker = new object();

    static void Increase()
    {
        for (int i = 0; i < 1000; i++)
        {
            lock (locker)
            {
                count++;
            }
        }
    }

    static void Main()
    {
        Thread t1 = new Thread(new ThreadStart(Increase));
        Thread t2 = new Thread(new ThreadStart(Increase));
        t1.Start();
        t2.Start();
        t1.Join();
        t2.Join();
        Console.WriteLine("Final count = " + count);
    }
}
