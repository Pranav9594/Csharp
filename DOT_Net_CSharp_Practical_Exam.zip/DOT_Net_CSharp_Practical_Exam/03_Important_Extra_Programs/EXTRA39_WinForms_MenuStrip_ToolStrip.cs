// ======================================================================
// Question No. : EXTRA39
// Question     : Write a Windows Forms application with a MenuStrip (File > Exit, Help > About) and a ToolStrip button.
// Topic        : Windows Forms - menus, MenuStrip and ToolStrip
// File         : EXTRA39_WinForms_MenuStrip_ToolStrip.cs
// Source       : Additional practice program (not from journal or ZIP)
// Type         : Windows Forms application (create a Windows Forms project, or a Console project
//                and change Output type to Windows Application; add references System.Windows.Forms and System.Drawing).
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Drawing;
using System.Windows.Forms;

class MenuForm : Form
{
    public MenuForm()
    {
        this.Text = "Menu and Toolbar";
        this.Size = new Size(400, 300);

        MenuStrip ms = new MenuStrip();

        ToolStripMenuItem file = new ToolStripMenuItem("File");
        ToolStripMenuItem exit = new ToolStripMenuItem("Exit");
        exit.Click += new EventHandler(exit_Click);
        file.DropDownItems.Add(exit);

        ToolStripMenuItem help = new ToolStripMenuItem("Help");
        ToolStripMenuItem about = new ToolStripMenuItem("About");
        about.Click += new EventHandler(about_Click);
        help.DropDownItems.Add(about);

        ms.Items.Add(file);
        ms.Items.Add(help);

        ToolStrip ts = new ToolStrip();
        ToolStripButton hello = new ToolStripButton("Hello");
        hello.Click += new EventHandler(hello_Click);
        ts.Items.Add(hello);

        this.Controls.Add(ts);
        this.Controls.Add(ms);
        this.MainMenuStrip = ms;
    }

    void exit_Click(object sender, EventArgs e)
    {
        Application.Exit();
    }

    void about_Click(object sender, EventArgs e)
    {
        MessageBox.Show("Menu example in C#");
    }

    void hello_Click(object sender, EventArgs e)
    {
        MessageBox.Show("Toolbar button clicked");
    }

    [STAThread]
    static void Main()
    {
        Application.Run(new MenuForm());
    }
}
