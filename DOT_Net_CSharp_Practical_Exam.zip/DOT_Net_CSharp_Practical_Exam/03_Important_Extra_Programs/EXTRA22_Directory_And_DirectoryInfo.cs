// ======================================================================
// Question No. : EXTRA22
// Question     : Write a C# program to create a directory and list the files in it using Directory and DirectoryInfo.
// Topic        : I/O - Directory and DirectoryInfo
// File         : EXTRA22_Directory_And_DirectoryInfo.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.IO;

class DirectoryDemo
{
    static void Main()
    {
        Directory.CreateDirectory("MyFolder");
        File.WriteAllText(Path.Combine("MyFolder", "a.txt"), "A");
        File.WriteAllText(Path.Combine("MyFolder", "b.txt"), "B");

        Console.WriteLine("Directory exists : " + Directory.Exists("MyFolder"));

        DirectoryInfo di = new DirectoryInfo("MyFolder");
        Console.WriteLine("Folder name : " + di.Name);

        FileInfo[] files = di.GetFiles();
        Console.WriteLine("Number of files : " + files.Length);
        foreach (FileInfo f in files)
        {
            Console.WriteLine(f.Name + "  " + f.Length + " bytes");
        }
    }
}
