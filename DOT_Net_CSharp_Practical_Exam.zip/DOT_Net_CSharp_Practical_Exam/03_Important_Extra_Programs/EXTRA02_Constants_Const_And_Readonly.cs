// ======================================================================
// Question No. : EXTRA02
// Question     : Write a C# program to demonstrate const and readonly fields.
// Topic        : Enum and constant
// File         : EXTRA02_Constants_Const_And_Readonly.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Circle
{
    public const double PI = 3.14;          // value fixed at compile time
    public readonly int radius;             // value fixed at run time (in constructor)

    public Circle(int r)
    {
        radius = r;
    }

    public double Area()
    {
        return PI * radius * radius;
    }
}

class ConstDemo
{
    static void Main()
    {
        Circle c = new Circle(5);
        Console.WriteLine("PI     = " + Circle.PI);
        Console.WriteLine("Radius = " + c.radius);
        Console.WriteLine("Area   = " + c.Area());
    }
}
