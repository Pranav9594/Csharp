// ======================================================================
// Question No. : EXTRA05
// Question     : Write a C# program to demonstrate method overriding using virtual and override (dynamic binding).
// Topic        : Polymorphism - virtual and override
// File         : EXTRA05_Virtual_Method_Overriding.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Shape
{
    public virtual void Draw()
    {
        Console.WriteLine("Drawing a shape");
    }
}

class Circle : Shape
{
    public override void Draw()
    {
        Console.WriteLine("Drawing a circle");
    }
}

class Square : Shape
{
    public override void Draw()
    {
        Console.WriteLine("Drawing a square");
    }
}

class OverrideDemo
{
    static void Main()
    {
        Shape s;

        s = new Shape();
        s.Draw();

        s = new Circle();
        s.Draw();

        s = new Square();
        s.Draw();
    }
}
