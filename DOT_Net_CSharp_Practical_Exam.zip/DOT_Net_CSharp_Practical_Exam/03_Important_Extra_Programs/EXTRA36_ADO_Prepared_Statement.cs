// ======================================================================
// Question No. : EXTRA36
// Question     : Write a C# program to insert a record using a prepared SqlCommand (Prepare method) with parameters.
// Topic        : ADO.NET - prepared statement
// File         : EXTRA36_ADO_Prepared_Statement.cs
// Source       : Additional practice program (not from journal or ZIP)
// Requires     : SQL Server Express + Employee table; change the connection string path.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class PreparedDemo
{
    static void Main()
    {
        SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\admin\Documents\Visual Studio 2010\Projects\WindowsFormsApplication7\WindowsFormsApplication7\Database1.mdf;Integrated Security=True;User Instance=True");
        cn.Open();

        SqlCommand cmd = new SqlCommand("insert into Employee values (@no,@nm)", cn);
        cmd.Parameters.Add("@no", SqlDbType.Int);
        cmd.Parameters.Add("@nm", SqlDbType.VarChar, 50);
        cmd.Prepare();

        cmd.Parameters["@no"].Value = 11;
        cmd.Parameters["@nm"].Value = "Ravi";
        cmd.ExecuteNonQuery();

        cmd.Parameters["@no"].Value = 12;
        cmd.Parameters["@nm"].Value = "Sita";
        cmd.ExecuteNonQuery();

        Console.WriteLine("Two records inserted");
        cn.Close();
    }
}
