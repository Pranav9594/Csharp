// ======================================================================
// Question No. : EXTRA31
// Question     : Write a C# program to create your own generic class.
// Topic        : Generics - custom generic class
// File         : EXTRA31_Custom_Generic_Class.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Box<T>
{
    private T item;

    public void Set(T value)
    {
        item = value;
    }

    public T Get()
    {
        return item;
    }
}

class GenericClassDemo
{
    static void Main()
    {
        Box<int> b1 = new Box<int>();
        b1.Set(100);
        Console.WriteLine("Integer box : " + b1.Get());

        Box<string> b2 = new Box<string>();
        b2.Set("Hello");
        Console.WriteLine("String box  : " + b2.Get());
    }
}
