// ======================================================================
// Question No. : EXTRA37
// Question     : Write a Windows Forms application with two text boxes, a button and a label to add two numbers. (The form is built in code, no designer needed.)
// Topic        : Windows Forms - basic controls
// File         : EXTRA37_WinForms_Add_Two_Numbers.cs
// Source       : Additional practice program (not from journal or ZIP)
// Type         : Windows Forms application (create a Windows Forms project, or a Console project
//                and change Output type to Windows Application; add references System.Windows.Forms and System.Drawing).
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Drawing;
using System.Windows.Forms;

class AddForm : Form
{
    Label l1, l2, lblResult;
    TextBox t1, t2;
    Button btn;

    public AddForm()
    {
        this.Text = "Add Two Numbers";
        this.Size = new Size(300, 250);

        l1 = new Label();
        l1.Text = "First number";
        l1.Location = new Point(20, 20);
        t1 = new TextBox();
        t1.Location = new Point(120, 20);

        l2 = new Label();
        l2.Text = "Second number";
        l2.Location = new Point(20, 60);
        t2 = new TextBox();
        t2.Location = new Point(120, 60);

        btn = new Button();
        btn.Text = "Add";
        btn.Location = new Point(120, 100);
        btn.Click += new EventHandler(btn_Click);

        lblResult = new Label();
        lblResult.Location = new Point(20, 140);
        lblResult.AutoSize = true;

        this.Controls.Add(l1);
        this.Controls.Add(t1);
        this.Controls.Add(l2);
        this.Controls.Add(t2);
        this.Controls.Add(btn);
        this.Controls.Add(lblResult);
    }

    void btn_Click(object sender, EventArgs e)
    {
        try
        {
            int a = Int32.Parse(t1.Text);
            int b = Int32.Parse(t2.Text);
            lblResult.Text = "Sum = " + (a + b);
        }
        catch (FormatException)
        {
            MessageBox.Show("Enter valid numbers");
        }
    }

    [STAThread]
    static void Main()
    {
        Application.Run(new AddForm());
    }
}
