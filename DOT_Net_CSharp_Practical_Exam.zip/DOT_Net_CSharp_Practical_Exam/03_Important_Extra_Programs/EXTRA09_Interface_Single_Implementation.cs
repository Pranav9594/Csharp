// ======================================================================
// Question No. : EXTRA09
// Question     : Write a C# program to implement an interface in a class.
// Topic        : Interface implementation
// File         : EXTRA09_Interface_Single_Implementation.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

interface IVehicle
{
    void Start();
    void Stop();
}

class Car : IVehicle
{
    public void Start()
    {
        Console.WriteLine("Car started");
    }

    public void Stop()
    {
        Console.WriteLine("Car stopped");
    }
}

class InterfaceDemo
{
    static void Main()
    {
        IVehicle v = new Car();
        v.Start();
        v.Stop();
    }
}
