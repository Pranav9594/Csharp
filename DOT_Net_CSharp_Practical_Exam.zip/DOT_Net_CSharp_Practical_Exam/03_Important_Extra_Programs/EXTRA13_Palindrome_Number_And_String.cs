// ======================================================================
// Question No. : EXTRA13
// Question     : Write a C# program to check whether a number and a string are palindromes.
// Topic        : Control statements and strings
// File         : EXTRA13_Palindrome_Number_And_String.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class PalindromeDemo
{
    static void Main()
    {
        int n, temp, rev = 0, digit;
        Console.Write("Enter a number: ");
        n = Convert.ToInt32(Console.ReadLine());
        temp = n;
        while (temp > 0)
        {
            digit = temp % 10;
            rev = rev * 10 + digit;
            temp = temp / 10;
        }
        if (rev == n)
            Console.WriteLine(n + " is a palindrome number");
        else
            Console.WriteLine(n + " is not a palindrome number");

        Console.Write("Enter a string: ");
        string s = Console.ReadLine();
        bool same = true;
        for (int i = 0; i < s.Length / 2; i++)
        {
            if (s[i] != s[s.Length - 1 - i])
            {
                same = false;
                break;
            }
        }
        if (same)
            Console.WriteLine(s + " is a palindrome string");
        else
            Console.WriteLine(s + " is not a palindrome string");
    }
}
