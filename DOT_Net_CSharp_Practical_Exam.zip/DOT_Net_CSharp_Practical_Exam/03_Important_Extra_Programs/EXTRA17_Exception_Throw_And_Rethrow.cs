// ======================================================================
// Question No. : EXTRA17
// Question     : Write a C# program to throw an exception using the throw keyword and handle it in the calling method.
// Topic        : Exception handling
// File         : EXTRA17_Exception_Throw_And_Rethrow.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class ThrowDemo
{
    static void CheckMarks(int marks)
    {
        if (marks < 0 || marks > 100)
        {
            throw new ArgumentException("Marks must be between 0 and 100");
        }
        Console.WriteLine("Marks accepted : " + marks);
    }

    static void Main()
    {
        try
        {
            CheckMarks(80);
            CheckMarks(150);
            Console.WriteLine("This line is not executed");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine("Error : " + ex.Message);
        }
        finally
        {
            Console.WriteLine("Finally block executed");
        }
    }
}
