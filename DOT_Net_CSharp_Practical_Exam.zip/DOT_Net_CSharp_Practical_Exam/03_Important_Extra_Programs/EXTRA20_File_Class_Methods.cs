// ======================================================================
// Question No. : EXTRA20
// Question     : Write a C# program to use the File class (Exists, WriteAllText, ReadAllText, AppendAllText, Copy, Delete).
// Topic        : I/O - File class
// File         : EXTRA20_File_Class_Methods.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.IO;

class FileDemo
{
    static void Main()
    {
        File.WriteAllText("one.txt", "Hello File Class\r\n");
        File.AppendAllText("one.txt", "Second line\r\n");

        if (File.Exists("one.txt"))
        {
            Console.WriteLine("one.txt exists");
            Console.WriteLine(File.ReadAllText("one.txt"));
        }

        File.Copy("one.txt", "two.txt", true);
        Console.WriteLine("two.txt exists : " + File.Exists("two.txt"));

        File.Delete("two.txt");
        Console.WriteLine("two.txt exists after delete : " + File.Exists("two.txt"));
    }
}
