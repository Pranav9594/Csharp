// ======================================================================
// Question No. : EXTRA23
// Question     : Write a C# program to write and read data in a binary file using BinaryWriter and BinaryReader.
// Topic        : I/O - binary stream
// File         : EXTRA23_Binary_File_BinaryWriter_BinaryReader.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.IO;

class BinaryDemo
{
    static void Main()
    {
        FileStream fs = new FileStream("data.bin", FileMode.Create);
        BinaryWriter bw = new BinaryWriter(fs);
        bw.Write(101);
        bw.Write("Rahul");
        bw.Write(85.5);
        bw.Close();
        fs.Close();

        fs = new FileStream("data.bin", FileMode.Open);
        BinaryReader br = new BinaryReader(fs);
        int id = br.ReadInt32();
        string name = br.ReadString();
        double marks = br.ReadDouble();
        br.Close();
        fs.Close();

        Console.WriteLine("Id    : " + id);
        Console.WriteLine("Name  : " + name);
        Console.WriteLine("Marks : " + marks);
    }
}
