// ======================================================================
// Question No. : EXTRA21
// Question     : Write a C# program to display information of a file using the FileInfo class.
// Topic        : I/O - FileInfo class
// File         : EXTRA21_FileInfo_Class.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.IO;

class FileInfoDemo
{
    static void Main()
    {
        File.WriteAllText("sample.txt", "This is a sample file.");

        FileInfo fi = new FileInfo("sample.txt");
        Console.WriteLine("Name      : " + fi.Name);
        Console.WriteLine("Extension : " + fi.Extension);
        Console.WriteLine("Size      : " + fi.Length + " bytes");
        Console.WriteLine("Exists    : " + fi.Exists);
        Console.WriteLine("Directory : " + fi.DirectoryName);
    }
}
