// ======================================================================
// Question No. : EXTRA03
// Question     : Write a C# program to demonstrate properties (get and set accessors).
// Topic        : Properties
// File         : EXTRA03_Properties_Get_Set.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Student
{
    private int marks;
    private string name;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public int Marks
    {
        get { return marks; }
        set
        {
            if (value >= 0 && value <= 100)
            {
                marks = value;
            }
            else
            {
                Console.WriteLine("Invalid marks");
            }
        }
    }
}

class PropertyDemo
{
    static void Main()
    {
        Student s = new Student();
        s.Name = "Rahul";
        s.Marks = 85;
        Console.WriteLine(s.Name + " has " + s.Marks + " marks");
        s.Marks = 150;      // rejected by the set accessor
        Console.WriteLine(s.Name + " has " + s.Marks + " marks");
    }
}
