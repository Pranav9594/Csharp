// ======================================================================
// Question No. : EXTRA26
// Question     : Write a C# program to demonstrate a multicast event using publisher and subscribers.
// Topic        : Delegates and events - multicast events
// File         : EXTRA26_Event_Publisher_Subscriber.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

delegate void ClickHandler();

class Button
{
    public event ClickHandler Clicked;

    public void Click()
    {
        Console.WriteLine("Button clicked");
        if (Clicked != null)
        {
            Clicked();
        }
    }
}

class EventDemo
{
    static void Hello()
    {
        Console.WriteLine("Subscriber 1 : Hello");
    }

    static void ThankYou()
    {
        Console.WriteLine("Subscriber 2 : Thank you");
    }

    static void Main()
    {
        Button b = new Button();
        b.Clicked += new ClickHandler(Hello);
        b.Clicked += new ClickHandler(ThankYou);
        b.Click();
    }
}
