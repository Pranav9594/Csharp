// ======================================================================
// Question No. : EXTRA06
// Question     : Write a C# program to show method hiding with the new keyword (static binding).
// Topic        : Polymorphism - static binding
// File         : EXTRA06_Method_Hiding_new_Keyword.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public void Show()
    {
        Console.WriteLine("Show of A");
    }
}

class B : A
{
    public new void Show()
    {
        Console.WriteLine("Show of B");
    }
}

class HidingDemo
{
    static void Main()
    {
        B b = new B();
        b.Show();           // Show of B

        A a = b;
        a.Show();           // Show of A (decided by reference type)
    }
}
