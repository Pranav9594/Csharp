// ======================================================================
// Question No. : EXTRA18
// Question     : Write a C# program to create a user defined exception for insufficient balance while withdrawing money.
// Topic        : Exception handling - custom exception
// File         : EXTRA18_Custom_Exception_Withdraw.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class InsufficientBalanceException : Exception
{
    public InsufficientBalanceException(string message) : base(message)
    {
    }
}

class Account
{
    private double balance = 5000;

    public void Withdraw(double amount)
    {
        if (amount > balance)
        {
            throw new InsufficientBalanceException("Insufficient balance. Available = " + balance);
        }
        balance = balance - amount;
        Console.WriteLine("Withdrawn " + amount + ". Balance = " + balance);
    }
}

class CustomExceptionDemo
{
    static void Main()
    {
        Account a = new Account();
        try
        {
            a.Withdraw(2000);
            a.Withdraw(4000);
        }
        catch (InsufficientBalanceException ex)
        {
            Console.WriteLine("Custom Exception : " + ex.Message);
        }
    }
}
