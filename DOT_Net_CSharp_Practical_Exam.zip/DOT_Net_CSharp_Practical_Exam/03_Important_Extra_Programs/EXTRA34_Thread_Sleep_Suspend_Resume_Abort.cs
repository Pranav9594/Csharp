// ======================================================================
// Question No. : EXTRA34
// Question     : Write a C# program to suspend, resume and terminate a thread.
// Topic        : Multithreading - suspending, resuming and terminating threads
// File         : EXTRA34_Thread_Sleep_Suspend_Resume_Abort.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Threading;

class ThreadControl
{
    static void Count()
    {
        for (int i = 1; i <= 100; i++)
        {
            Console.WriteLine("Counting " + i);
            Thread.Sleep(200);
        }
    }

    static void Main()
    {
        Thread t = new Thread(new ThreadStart(Count));
        t.Start();
        Thread.Sleep(700);

        t.Suspend();
        Console.WriteLine("Thread suspended");
        Thread.Sleep(1000);

        t.Resume();
        Console.WriteLine("Thread resumed");
        Thread.Sleep(500);

        t.Abort();
        Console.WriteLine("Thread terminated");
        t.Join();
    }
}
