// ======================================================================
// Question No. : EXTRA30
// Question     : Write a C# program to demonstrate the generic collection classes List<T> and Dictionary<K,V>.
// Topic        : Generics - generic collections
// File         : EXTRA30_Generic_List_And_Dictionary.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Collections.Generic;

class GenericCollections
{
    static void Main()
    {
        List<int> numbers = new List<int>();
        numbers.Add(40);
        numbers.Add(10);
        numbers.Add(30);
        numbers.Sort();
        Console.WriteLine("Sorted list:");
        foreach (int n in numbers)
        {
            Console.WriteLine(n);
        }

        Dictionary<int, string> d = new Dictionary<int, string>();
        d.Add(1, "BCA");
        d.Add(2, "BBA");
        d.Add(3, "MCA");
        Console.WriteLine("Course 2 : " + d[2]);
        foreach (KeyValuePair<int, string> kv in d)
        {
            Console.WriteLine(kv.Key + " - " + kv.Value);
        }
    }
}
