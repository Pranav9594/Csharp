// ======================================================================
// Question No. : EXTRA04
// Question     : Write a C# program to demonstrate an indexer.
// Topic        : Indexer
// File         : EXTRA04_Indexer_Example.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Names
{
    private string[] data = new string[3];

    public string this[int index]
    {
        get { return data[index]; }
        set { data[index] = value; }
    }
}

class IndexerDemo
{
    static void Main()
    {
        Names n = new Names();
        n[0] = "Amit";
        n[1] = "Neha";
        n[2] = "Raj";

        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine("n[" + i + "] = " + n[i]);
        }
    }
}
