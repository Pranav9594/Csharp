// ======================================================================
// Question No. : EXTRA25
// Question     : Write a C# program to demonstrate lambda expressions.
// Topic        : Delegates - lambda expression
// File         : EXTRA25_Lambda_Expression.cs
// Source       : Additional practice program (not from journal or ZIP)
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Collections.Generic;

delegate int Operation(int x, int y);

class LambdaDemo
{
    static void Main()
    {
        Operation add = (x, y) => x + y;
        Console.WriteLine("Add = " + add(4, 6));

        Func<int, int> square = n => n * n;
        Console.WriteLine("Square of 7 = " + square(7));

        List<int> list = new List<int>();
        list.Add(5);
        list.Add(12);
        list.Add(8);
        list.Add(21);

        List<int> even = list.FindAll(n => n % 2 == 0);
        Console.WriteLine("Even numbers:");
        foreach (int n in even)
        {
            Console.WriteLine(n);
        }
    }
}
