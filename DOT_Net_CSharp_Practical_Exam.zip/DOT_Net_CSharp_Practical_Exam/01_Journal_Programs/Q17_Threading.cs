// ======================================================================
// Question No. : Q17
// Question     : Develop a C# program to implement threading concepts.
// Topic        : Unit 6 - Threads, delegates and events
// File         : Q17_Threading.cs
// Source       : Practical journal: Q17_Threading.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Threading;

class MultiThreadDemo
{
    // Method for first thread
    public static void PrintNumbers()
    {
        for (int i = 1; i <= 5; i++)
        {
            Console.WriteLine("Number Thread: " + i);
            Thread.Sleep(500);
        }
    }

    // Method for second thread
    public static void PrintCharacters()
    {
        for (char ch = 'A'; ch <= 'E'; ch++)
        {
            Console.WriteLine("Character Thread: " + ch);
            Thread.Sleep(500);
        }
    }

    static void Main(string[] args)
    {
        Thread t1 = new Thread(new ThreadStart(PrintNumbers));
        Thread t2 = new Thread(new ThreadStart(PrintCharacters));

        t1.Start();
        t2.Start();

        // wait for both threads to complete
        t1.Join();
        t2.Join();

        Console.WriteLine("Both threads have finished execution.");
    }
}
