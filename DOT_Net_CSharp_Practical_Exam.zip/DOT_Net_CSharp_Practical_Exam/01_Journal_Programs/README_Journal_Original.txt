BCA SEMESTER V - LAB ON DOT NET AND C# (Course Code 506)
COMPLETE PRACTICAL ASSIGNMENT - 18 PROGRAMS
============================================================

GENERAL INFORMATION
-------------------
* Language: C# 4.0 syntax, .NET Framework 4.0, Microsoft Visual Studio 2010.
* Programs were written following the college reference codes (Codes.zip,
  C__Codes.zip, WindowsFormsApplication10.zip) and the syllabus.
* IMPORTANT: Visual Studio 2010 and SQL Server were NOT available while
  preparing this assignment, so the programs were NOT compiled or run here.
  Only static checks were done (syntax, brace balance, names used in the Windows
  Forms project, logic walk-through). The sample outputs were worked out by
  hand from the code. Please build and run once before submission.

HOW TO RUN A CONSOLE PROGRAM (Q1-Q14, Q16-Q18) IN VISUAL STUDIO 2010
---------------------------------------------------------------------
1. File -> New -> Project -> Visual C# -> Console Application.
2. Open Program.cs, delete everything and paste the code of the .cs file
   (or Project -> Add Existing Item and then remove the default Program.cs).
3. Only ONE file with a Main() method may be in a project, so create a new
   project for each question.
4. Press Ctrl+F5 (Start Without Debugging) so the console stays open.
Alternative: open Developer Command Prompt and use  csc Q1_Calculator.cs


============================================================
Q1. Write a C# Program to design simple calculator.  [Unit 1]
============================================================
File    : Unit_1_Basic_Console/Q1_Calculator.cs
Aim     : To design a simple calculator that performs addition, subtraction, multiplication and division.
Explanation: A menu is shown and the choice is read. A switch statement performs the selected operation on two numbers. Division by zero is checked with an if statement. A do-while loop lets the user calculate again.

Sample output:
    ----- Simple Calculator -----
    1. Addition
    2. Subtraction
    3. Multiplication
    4. Division
    Enter your choice (1-4): 4
    Enter first number: 20
    Enter second number: 4
    Quotient = 5
    Do you want to continue (y/n)? y
    
    ----- Simple Calculator -----
    1. Addition
    2. Subtraction
    3. Multiplication
    4. Division
    Enter your choice (1-4): 1
    Enter first number: 12.5
    Enter second number: 7.5
    Sum = 20
    Do you want to continue (y/n)? n

============================================================
Q2. Write a console application that obtains four int values from the user and displays the product.  [Unit 1]
============================================================
File    : Unit_1_Basic_Console/Q2_Product.cs
Aim     : To read four integer values and display their product.
Explanation: Four integers are read with Convert.ToInt32. The product is stored in a long variable (the first value is cast to long) so that a large product does not overflow.

Sample output:
    Enter first integer: 2
    Enter second integer: 3
    Enter third integer: 4
    Enter fourth integer: 5
    Product of 2, 3, 4 and 5 = 120

============================================================
Q3. If you have two integers stored in variables var1 and var2, what Boolean test can you perform to see if one or the other (but not both) is greater than 10?  [Unit 1]
============================================================
File    : Unit_1_Basic_Console/Q3_BooleanTest.cs
Aim     : To test whether exactly one of two integers is greater than 10.
Explanation: The test is (var1 > 10 && var2 <= 10) || (var1 <= 10 && var2 > 10). The same test can be written with the exclusive OR operator: (var1 > 10) ^ (var2 > 10). Both are displayed.

Sample output:
    Enter value of var1: 15
    Enter value of var2: 8
    Result using && and || : True
    Result using ^ operator : True
    Only one of the two values is greater than 10

============================================================
Q4. Write an application that receives Student Id, Student Name, Course Name and Date of Birth from a set of students and displays the information of all students. Implement using an Array of Structures.  [Unit 1]
============================================================
File    : Unit_1_Basic_Console/Q4_ArrayOfStructures.cs
Aim     : To store and display student information using an array of structures.
Explanation: A struct named Student has four fields. An array of Student (Student[] s = new Student[n]) is created after reading the number of students. A for loop reads the details and another for loop displays them. The date of birth is stored as text in dd/mm/yyyy form.

Sample output:
    Enter number of students: 2
    Enter details of student 1
    Student Id: 101
    Student Name: Rahul Shah
    Course Name: BCA
    Date of Birth (dd/mm/yyyy): 12/05/2004
    Enter details of student 2
    Student Id: 102
    Student Name: Priya Mehta
    Course Name: BCA
    Date of Birth (dd/mm/yyyy): 03/11/2003
    
    ----- Student Information -----
    Student Id    : 101
    Student Name  : Rahul Shah
    Course Name   : BCA
    Date of Birth : 12/05/2004
    
    Student Id    : 102
    Student Name  : Priya Mehta
    Course Name   : BCA
    Date of Birth : 03/11/2003
    

============================================================
Q5. Write a C# Program to Get a Number and Display the Number with its Reverse.  [Unit 1]
============================================================
File    : Unit_1_Basic_Console/Q5_NumberReverse.cs
Aim     : To read a number and display it along with its reverse.
Explanation: Digits are extracted with % 10, added to rev (rev = rev * 10 + digit) and removed with / 10 inside a while loop. Negative numbers are handled by reversing the positive value and restoring the sign. Trailing zeros disappear (1200 gives 21).

Sample output:
    Enter a number: 12345
    Number = 12345
    Reverse = 54321

============================================================
Q6. Write a Program in C# to demonstrate Command line arguments processing.  [Unit 1]
============================================================
File    : Unit_1_Basic_Console/Q6_CommandLineArguments.cs
Aim     : To process arguments passed to Main(string[] args) from the command line.
Explanation: args.Length gives the number of arguments. A for loop displays each argument. int.TryParse is used to add up the arguments that are numbers.

Execution:
Method 1 - Visual Studio 2010:
  1. Project menu -> <ProjectName> Properties.
  2. Open the 'Debug' tab.
  3. In 'Command line arguments' type:  10 20 Hello
  4. Press Ctrl+F5 to run.
Method 2 - Command prompt: go to bin\Debug and run
  ProjectName.exe 10 20 Hello

Sample output:
    (with arguments:  10 20 Hello)
    Number of arguments = 3
    args[0] = 10
    args[1] = 20
    args[2] = Hello
    Sum of the numeric arguments = 30
    
    (without arguments)
    No command-line arguments were passed.
    Usage: Q6_CommandLineArguments 10 20 Hello

============================================================
Q7. Write a Program in C# to demonstrate boxing and unboxing.  [Unit 1]
============================================================
File    : Unit_1_Basic_Console/Q7_BoxingAndUnboxing.cs
Aim     : To show conversion of a value type to object (boxing) and back (unboxing).
Explanation: object obj = x; is boxing. int y = (int)obj; is unboxing. Changing x after boxing does not change obj because obj holds a copy. Unboxing to the wrong type (double) throws InvalidCastException, which is caught.

Sample output:
    Value of x = 200
    Boxed object = 100
    Unboxed value y = 100
    Cannot unbox an int object to double

============================================================
Q8. Write a C# Program to Display the Date in Various Formats.  [Unit 2]
============================================================
File    : Unit_2_Date_And_Time/Q8_DateFormats.cs
Aim     : To display a date in different standard and custom formats.
Explanation: A fixed DateTime (15 March 2024, 2:30:45 PM) is used. Standard methods (ToShortDateString etc.) and ToString() with format strings are used. The first five lines depend on the Windows regional settings; the sample shows English (United States).

Sample output:
    Default Format      : 3/15/2024 2:30:45 PM
    Short Date          : 3/15/2024
    Long Date           : Friday, March 15, 2024
    Short Time          : 2:30 PM
    Long Time           : 2:30:45 PM
    dd/MM/yyyy          : 15/03/2024
    MM-dd-yyyy          : 03-15-2024
    yyyy-MM-dd          : 2024-03-15
    dd MMM yyyy         : 15 Mar 2024
    MMMM dd, yyyy       : March 15, 2024
    dddd, dd MMMM yyyy  : Friday, 15 March 2024
    hh:mm:ss tt         : 02:30:45 PM
    HH:mm:ss (24 hour)  : 14:30:45

============================================================
Q9. Write a C# Program to Check Whether the Entered Year is a Leap Year or Not.  [Unit 2]
============================================================
File    : Unit_2_Date_And_Time/Q9_LeapYear.cs
Aim     : To check whether a year is a leap year.
Explanation: A year is a leap year if it is divisible by 4 but not by 100, or if it is divisible by 400.

Sample output:
    Enter a year: 2024
    2024 is a Leap Year
    
    Enter a year: 1900
    1900 is not a Leap Year

============================================================
Q10. Write a C# Program to find difference between Two Dates.  [Unit 2]
============================================================
File    : Unit_2_Date_And_Time/Q10_DateDifference.cs
Aim     : To find the difference between two dates in total days and in years, months and days.
Explanation: Total days = (date2 - date1).Days using TimeSpan. For years/months/days: (1) count the whole months between the dates using the year and month numbers; (2) if date1.AddMonths(months) goes beyond date2, reduce months by 1; (3) days = date2 - date1.AddMonths(months); (4) years = months / 12 and months = months % 12. No 30-day month or 365-day year approximation is used, and the result is never negative. If the first date is later, the dates are swapped.

Sample output:
    Enter first date
    Day: 15
    Month: 8
    Year: 2000
    Enter second date
    Day: 20
    Month: 11
    Year: 2024
    Total days = 8863
    Difference = 24 year(s), 3 month(s), 5 day(s)

============================================================
Q11. Write a program to demonstrate abstract class and abstract methods in C#.  [Unit 3]
============================================================
File    : Unit_3_Classes/Q11_AbstractClass.cs
Aim     : To demonstrate an abstract class with an abstract method overridden in derived classes.
Explanation: Shape is abstract and declares abstract CalculateArea(). Rectangle and Circle override it. An abstract class cannot be instantiated, so a Shape reference holds the derived objects.

Sample output:
    Rectangle (length 5, breadth 4)
    Area = 20
    Circle (radius 3)
    Area = 28.26

============================================================
Q12. Find the sum of all the elements present in a jagged array of 3 inner arrays.  [Unit 3]
============================================================
File    : Unit_3_Classes/Q12_JaggedArray.cs
Aim     : To create a jagged array with 3 inner arrays and find the sum of all elements.
Explanation: int[][] a = new int[3][] creates three rows; each row is given its own length ({1,2,3}, {4,5}, {6,7,8,9}). Nested for loops add all the elements.

Sample output:
    Inner array 1 : 1 2 3 
    Inner array 2 : 4 5 
    Inner array 3 : 6 7 8 9 
    Sum of all elements = 45

============================================================
Q13. Write a program to demonstrate Operator overloading.  [Unit 3]
============================================================
File    : Unit_3_Classes/Q13_OperatorOverloading.cs
Aim     : To overload the + and - operators for a user-defined Complex class.
Explanation: public static Complex operator +(Complex c1, Complex c2) returns a new Complex whose parts are added. The - operator works the same way.

Sample output:
    First number  : 5 + 3i
    Second number : 2 + 4i
    Sum           : 7 + 7i
    Difference    : 3 + -1i

============================================================
Q14. Demonstrate arrays of interface types (for runtime polymorphism) with a C# program.  [Unit 3]
============================================================
File    : Unit_3_Classes/Q14_InterfaceArray.cs
Aim     : To use an array of interface type to call methods of different classes (runtime polymorphism).
Explanation: IShape[] holds Circle, Rectangle and Triangle objects. The call shapes[i].Draw() runs the method of the actual object at run time.

Sample output:
    Drawing a Circle
    Area = 12.56
    Drawing a Rectangle
    Area = 20
    Drawing a Triangle
    Area = 9

============================================================
Q15. STUDENT database (Course, Student). Windows application with 4 options: new course, new student, students of a course in a grid, students admitted in a particular year.  [Unit 4]
============================================================
File    : Unit_4_ADO_NET/StudentApplication/ (Form1.cs, Form1.Designer.cs, Program.cs, ...)
Aim     : To develop a Windows Forms application using ADO.NET (SqlConnection, SqlCommand, SqlDataAdapter, DataGridView) with SQL Server Express.
Explanation: One form with a TabControl; each tab is one option. Tab 1 and Tab 2 insert records with SqlCommand and parameters. Tab 3 and Tab 4 fill a DataTable with SqlDataAdapter and show it in a DataGridView. The connection string follows the college project: Data Source=.\SQLEXPRESS; AttachDbFilename=...STUDENT.mdf; Integrated Security=True; User Instance=True. See 'Q15 SETUP' below.

Sample output:
    Tab 'New Course'      : ID 3, Name MCA, click Add Course -> "Course Inserted Successfully"
    Tab 'New Student'     : 104, Sneha Joshi, Nashik, Course 1, Year 2023 -> "Student Inserted Successfully"
    Tab 'Students by Course', Course ID 1 -> grid:
      RollNo  S_Name        Address  C_ID  C_Name  Admissionyear
      101     Rahul Shah    Mumbai   1     BCA     2022
      102     Priya Mehta   Thane    1     BCA     2023
      104     Sneha Joshi   Nashik   1     BCA     2023
    Tab 'Students by Year', Year 2022 -> grid:
      RollNo  S_Name        Address  C_ID  C_Name  Admissionyear
      101     Rahul Shah    Mumbai   1     BCA     2022
      103     Amit Patil    Pune     2     BBA     2022
    (Rows 101-103 come from the optional sample data in STUDENT_CreateTables.sql.)

============================================================
Q16. Write a program in C# to demonstrate error handling.  [Unit 5]
============================================================
File    : Unit_5_Exception_Handling/Q16_ExceptionHandling.cs
Aim     : To handle run-time errors using try, catch and finally.
Explanation: Example 1 divides two numbers (DivideByZeroException / FormatException). Example 2 accesses an invalid array index (IndexOutOfRangeException). Example 3 reads an age with a wrong input (FormatException). Every example has a finally block that always runs.

Sample output:
    Enter first number: 10
    Enter second number: 0
    Error : Attempted to divide by zero.
    Finally block of example 1 executed
    
    Accessing numbers[5]
    Error : Index was outside the bounds of the array.
    Finally block of example 2 executed
    
    Enter your age: abc
    Error : Input string was not in a correct format.
    Finally block of example 3 executed

============================================================
Q17. Develop a C# program to implement threading concepts.  [Unit 6]
============================================================
File    : Unit_6_Events_And_Delegates/Q17_Threading.cs
Aim     : To create and run two threads at the same time.
Explanation: Based on threadex.cs from the college codes. Two Thread objects run PrintNumbers and PrintCharacters. Thread.Sleep(500) pauses each thread. Join() makes Main wait until both threads finish. The order of lines may vary slightly from run to run.

Sample output:
    Number Thread: 1
    Character Thread: A
    Number Thread: 2
    Character Thread: B
    Number Thread: 3
    Character Thread: C
    Number Thread: 4
    Character Thread: D
    Number Thread: 5
    Character Thread: E
    Both threads have finished execution.

============================================================
Q18. Develop a C# program to implement (a) Delegates (b) Events.  [Unit 6]
============================================================
File    : Unit_6_Events_And_Delegates/Q18_DelegatesAndEvents.cs
Aim     : To demonstrate delegates and events.
Explanation: (a) delegate int Operation(int x, int y) is pointed to Add and then Multiply. (b) The Alarm class declares an event Ring of type AlarmHandler. Two Person objects subscribe with +=. When Start() raises the event, both subscribers' Wake methods run.

Sample output:
    ----- Delegates -----
    Addition = 15
    Multiplication = 50
    
    ----- Events -----
    Alarm started...
    Amit received the alarm : Wake up! Time is over.
    Neha received the alarm : Wake up! Time is over.

============================================================
Q15 SETUP - STUDENT DATABASE AND WINDOWS FORMS PROJECT
============================================================
Software needed: Visual Studio 2010 and SQL Server Express (2005/2008) with the
instance name .\SQLEXPRESS - the same as the college project
(WindowsFormsApplication10).

Files in Unit_4_ADO_NET:
  StudentApplication.sln, StudentApplication\StudentApplication.csproj,
  Form1.cs (code), Form1.Designer.cs (form design), Form1.resx, Program.cs,
  Properties\AssemblyInfo.cs, STUDENT_CreateTables.sql

Note: the file STUDENT.mdf could not be created without SQL Server, so you
create it once in Visual Studio (steps below, about 3 minutes).

Step 1 - Open the project
  Double-click StudentApplication.sln. Build -> Build Solution (it should build
  without errors).

Step 2 - Create the STUDENT database
  a. Solution Explorer -> right-click project 'StudentApplication' -> Add ->
     New Item -> Data -> 'Service-based Database'.
  b. Name it exactly:  STUDENT.mdf  -> Add.
  c. If the 'Data Source Configuration Wizard' appears, click Cancel (not needed).
  d. Select STUDENT.mdf in Solution Explorer -> in the Properties window set
     'Copy to Output Directory' = 'Copy if newer'  (NOT 'Copy always', otherwise
     your data is overwritten every time you run).

Step 3 - Create the two tables (Course and Student)
  a. View -> Server Explorer (Database Explorer in Express editions).
  b. Expand Data Connections -> STUDENT.mdf -> right-click 'Tables' -> New Query
     (or right-click STUDENT.mdf -> New Query).
  c. Paste the whole content of STUDENT_CreateTables.sql and click Execute (Ctrl+Shift+E).
     (The last 5 INSERT lines are optional sample data.)
  d. Right-click Tables -> Refresh. You should see Course and Student.
     Course : C_ID int, C_Name varchar(50)
     Student: RollNo int, S_Name varchar(50), Address varchar(100), C_ID int, Admissionyear int
  e. Right-click STUDENT.mdf -> Close Connection (so the file is not locked).

Step 4 - Connection string (already written in Form1.cs)
  Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\STUDENT.mdf;Integrated Security=True;User Instance=True
  |DataDirectory| is the folder where the exe runs (bin\Debug), where Visual Studio
  copies STUDENT.mdf. If you want the college style (full path), replace
  |DataDirectory|\STUDENT.mdf by the full path of the file, e.g.
  C:\Users\admin\documents\visual studio 2010\Projects\StudentApplication\StudentApplication\STUDENT.mdf

Step 5 - Run (F5) and use the four tabs
  1. New Course        - enter Course ID and Course Name, click Add Course.
  2. New Student       - enter Roll No, Name, Address, Course ID (a course that
                         already exists), Admission Year, click Add Student.
  3. Students by Course- enter Course ID, click Show Students (grid).
  4. Students by Year  - enter Admission Year, click Show Students (grid).

Troubleshooting
  * 'Cannot attach the file' / 'User Instance' error: close the Server Explorer
    connection to STUDENT.mdf (Step 3e) and run again; make sure SQL Server
    (SQLEXPRESS) service is running.
  * 'Foreign key conflict' message: add the course first (Tab 1) before adding a
    student with that Course ID.
  * 'Violation of PRIMARY KEY': the Course ID / Roll No already exists.
  * If you have SQL Server Express 2012 or later, 'User Instance=True' is not
    supported. Use LocalDB instead:
    Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\STUDENT.mdf;Integrated Security=True
    (Visual Studio 2010 needs SP1 + the SQL Server 2012 LocalDB for this.)

VISUAL STUDIO 2010 COMPATIBILITY
--------------------------------
* No string interpolation, no async/await, no ?. operator, no expression-bodied
  members and no inline 'out int n' declarations (all C# 6/7 features).
* Q6 uses int.TryParse with a previously declared variable (C# 4.0 compatible).
* Windows Forms project: ToolsVersion 4.0, .NET Framework 4.0 Client Profile,
  solution format version 11.00 (Visual Studio 2010).
