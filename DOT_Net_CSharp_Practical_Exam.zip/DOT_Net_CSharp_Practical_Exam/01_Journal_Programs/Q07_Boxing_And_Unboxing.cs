// ======================================================================
// Question No. : Q07
// Question     : Write a Program in C# to demonstrate boxing and unboxing.
// Topic        : Unit 1 - Basic console programs
// File         : Q07_Boxing_And_Unboxing.cs
// Source       : Practical journal: Q7_BoxingAndUnboxing.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class BoxingDemo
{
    static void Main()
    {
        int x = 100;

        // Boxing : value type is converted to object (reference type)
        object obj = x;

        // changing x does not change the boxed copy
        x = 200;

        Console.WriteLine("Value of x = " + x);
        Console.WriteLine("Boxed object = " + obj);

        // Unboxing : object is converted back to value type
        int y = (int)obj;
        Console.WriteLine("Unboxed value y = " + y);

        // Unboxing to a wrong type gives an error
        try
        {
            double d = (double)obj;
            Console.WriteLine(d);
        }
        catch (InvalidCastException)
        {
            Console.WriteLine("Cannot unbox an int object to double");
        }
    }
}
