// ======================================================================
// Question No. : Q16
// Question     : Write a program in C# to demonstrate error handling.
// Topic        : Unit 5 - Exception handling
// File         : Q16_Exception_Handling.cs
// Source       : Practical journal: Q16_ExceptionHandling.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class ExceptionDemo
{
    static void Main()
    {
        int a, b, result;

        // Example 1 : DivideByZeroException
        try
        {
            Console.Write("Enter first number: ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            b = Convert.ToInt32(Console.ReadLine());

            result = a / b;
            Console.WriteLine("Result = " + result);
        }
        catch (DivideByZeroException ex)
        {
            Console.WriteLine("Error : " + ex.Message);
        }
        catch (FormatException ex)
        {
            Console.WriteLine("Error : " + ex.Message);
        }
        finally
        {
            Console.WriteLine("Finally block of example 1 executed");
        }

        Console.WriteLine();

        // Example 2 : IndexOutOfRangeException
        try
        {
            int[] numbers = { 10, 20, 30 };
            Console.WriteLine("Accessing numbers[5]");
            Console.WriteLine(numbers[5]);
        }
        catch (IndexOutOfRangeException ex)
        {
            Console.WriteLine("Error : " + ex.Message);
        }
        finally
        {
            Console.WriteLine("Finally block of example 2 executed");
        }

        Console.WriteLine();

        // Example 3 : FormatException
        try
        {
            Console.Write("Enter your age: ");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Your age is " + age);
        }
        catch (FormatException ex)
        {
            Console.WriteLine("Error : " + ex.Message);
        }
        finally
        {
            Console.WriteLine("Finally block of example 3 executed");
        }
    }
}
