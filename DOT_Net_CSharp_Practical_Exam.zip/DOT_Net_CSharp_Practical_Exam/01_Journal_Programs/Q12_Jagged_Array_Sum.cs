// ======================================================================
// Question No. : Q12
// Question     : Find the sum of all the elements present in a jagged array of 3 inner arrays.
// Topic        : Unit 3 - Classes and OOP
// File         : Q12_Jagged_Array_Sum.cs
// Source       : Practical journal: Q12_JaggedArray.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class JaggedArray
{
    static void Main()
    {
        int[][] a = new int[3][];

        a[0] = new int[] { 1, 2, 3 };
        a[1] = new int[] { 4, 5 };
        a[2] = new int[] { 6, 7, 8, 9 };

        int i, j, sum = 0;

        for (i = 0; i < a.Length; i++)
        {
            Console.Write("Inner array " + (i + 1) + " : ");
            for (j = 0; j < a[i].Length; j++)
            {
                Console.Write(a[i][j] + " ");
                sum = sum + a[i][j];
            }
            Console.WriteLine();
        }

        Console.WriteLine("Sum of all elements = " + sum);
    }
}
