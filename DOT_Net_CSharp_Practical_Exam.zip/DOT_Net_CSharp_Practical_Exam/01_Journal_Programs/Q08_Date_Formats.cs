// ======================================================================
// Question No. : Q08
// Question     : Write a C# Program to Display the Date in Various Formats.
// Topic        : Unit 2 - Date and time
// File         : Q08_Date_Formats.cs
// Source       : Practical journal: Q8_DateFormats.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class DateFormats
{
    static void Main()
    {
        DateTime d = new DateTime(2024, 3, 15, 14, 30, 45);

        Console.WriteLine("Default Format      : " + d);
        Console.WriteLine("Short Date          : " + d.ToShortDateString());
        Console.WriteLine("Long Date           : " + d.ToLongDateString());
        Console.WriteLine("Short Time          : " + d.ToShortTimeString());
        Console.WriteLine("Long Time           : " + d.ToLongTimeString());

        Console.WriteLine("dd/MM/yyyy          : " + d.ToString("dd/MM/yyyy"));
        Console.WriteLine("MM-dd-yyyy          : " + d.ToString("MM-dd-yyyy"));
        Console.WriteLine("yyyy-MM-dd          : " + d.ToString("yyyy-MM-dd"));
        Console.WriteLine("dd MMM yyyy         : " + d.ToString("dd MMM yyyy"));
        Console.WriteLine("MMMM dd, yyyy       : " + d.ToString("MMMM dd, yyyy"));
        Console.WriteLine("dddd, dd MMMM yyyy  : " + d.ToString("dddd, dd MMMM yyyy"));
        Console.WriteLine("hh:mm:ss tt         : " + d.ToString("hh:mm:ss tt"));
        Console.WriteLine("HH:mm:ss (24 hour)  : " + d.ToString("HH:mm:ss"));
    }
}
