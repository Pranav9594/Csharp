// ======================================================================
// Question No. : Q04
// Question     : Write an application that receives Student Id, Student Name, Course Name and Date of Birth from a set of students and displays the information of all students. Implement using an Array of Structures.
// Topic        : Unit 1 - Basic console programs
// File         : Q04_Student_Array_Of_Structures.cs
// Source       : Practical journal: Q4_ArrayOfStructures.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

struct Student
{
    public int id;
    public string name;
    public string course;
    public string dob;
}

class Program
{
    static void Main()
    {
        int n, i;

        Console.Write("Enter number of students: ");
        n = Convert.ToInt32(Console.ReadLine());

        Student[] s = new Student[n];

        for (i = 0; i < n; i++)
        {
            Console.WriteLine("Enter details of student " + (i + 1));
            Console.Write("Student Id: ");
            s[i].id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Student Name: ");
            s[i].name = Console.ReadLine();
            Console.Write("Course Name: ");
            s[i].course = Console.ReadLine();
            Console.Write("Date of Birth (dd/mm/yyyy): ");
            s[i].dob = Console.ReadLine();
        }

        Console.WriteLine();
        Console.WriteLine("----- Student Information -----");
        for (i = 0; i < n; i++)
        {
            Console.WriteLine("Student Id    : " + s[i].id);
            Console.WriteLine("Student Name  : " + s[i].name);
            Console.WriteLine("Course Name   : " + s[i].course);
            Console.WriteLine("Date of Birth : " + s[i].dob);
            Console.WriteLine();
        }
    }
}
