// ======================================================================
// Question No. : Q13
// Question     : Write a program to demonstrate Operator overloading.
// Topic        : Unit 3 - Classes and OOP
// File         : Q13_Operator_Overloading.cs
// Source       : Practical journal: Q13_OperatorOverloading.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Complex
{
    private int real, imag;

    public Complex(int r, int i)
    {
        real = r;
        imag = i;
    }

    public static Complex operator +(Complex c1, Complex c2)
    {
        return new Complex(c1.real + c2.real, c1.imag + c2.imag);
    }

    public static Complex operator -(Complex c1, Complex c2)
    {
        return new Complex(c1.real - c2.real, c1.imag - c2.imag);
    }

    public void Display()
    {
        Console.WriteLine(real + " + " + imag + "i");
    }
}

class Program
{
    static void Main()
    {
        Complex c1 = new Complex(5, 3);
        Complex c2 = new Complex(2, 4);
        Complex c3;

        Console.Write("First number  : ");
        c1.Display();
        Console.Write("Second number : ");
        c2.Display();

        c3 = c1 + c2;
        Console.Write("Sum           : ");
        c3.Display();

        c3 = c1 - c2;
        Console.Write("Difference    : ");
        c3.Display();
    }
}
