// ======================================================================
// Question No. : Q14
// Question     : Demonstrate arrays of interface types (for runtime polymorphism) with a C# program.
// Topic        : Unit 3 - Classes and OOP
// File         : Q14_Interface_Array_Polymorphism.cs
// Source       : Practical journal: Q14_InterfaceArray.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

interface IShape
{
    void Draw();
    double Area();
}

class Circle : IShape
{
    private double radius;

    public Circle(double r)
    {
        radius = r;
    }

    public void Draw()
    {
        Console.WriteLine("Drawing a Circle");
    }

    public double Area()
    {
        return 3.14 * radius * radius;
    }
}

class Rectangle : IShape
{
    private double length, breadth;

    public Rectangle(double l, double b)
    {
        length = l;
        breadth = b;
    }

    public void Draw()
    {
        Console.WriteLine("Drawing a Rectangle");
    }

    public double Area()
    {
        return length * breadth;
    }
}

class Triangle : IShape
{
    private double b, h;

    public Triangle(double bs, double ht)
    {
        b = bs;
        h = ht;
    }

    public void Draw()
    {
        Console.WriteLine("Drawing a Triangle");
    }

    public double Area()
    {
        return 0.5 * b * h;
    }
}

class Program
{
    static void Main()
    {
        IShape[] shapes = new IShape[3];

        shapes[0] = new Circle(2);
        shapes[1] = new Rectangle(4, 5);
        shapes[2] = new Triangle(6, 3);

        for (int i = 0; i < shapes.Length; i++)
        {
            shapes[i].Draw();
            Console.WriteLine("Area = " + shapes[i].Area());
        }
    }
}
