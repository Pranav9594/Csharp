// ======================================================================
// Question No. : Q06
// Question     : Write a Program in C# to demonstrate Command line arguments processing.
// Topic        : Unit 1 - Basic console programs
// File         : Q06_Command_Line_Arguments.cs
// Source       : Practical journal: Q6_CommandLineArguments.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class CommandLineDemo
{
    static void Main(string[] args)
    {
        int i, n, sum = 0;

        if (args.Length == 0)
        {
            Console.WriteLine("No command-line arguments were passed.");
            Console.WriteLine("Usage: Q6_CommandLineArguments 10 20 Hello");
        }
        else
        {
            Console.WriteLine("Number of arguments = " + args.Length);

            for (i = 0; i < args.Length; i++)
            {
                Console.WriteLine("args[" + i + "] = " + args[i]);

                if (int.TryParse(args[i], out n))
                {
                    sum = sum + n;
                }
            }

            Console.WriteLine("Sum of the numeric arguments = " + sum);
        }
    }
}
