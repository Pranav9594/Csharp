// ======================================================================
// Question No. : Q01
// Question     : Write a C# Program to design simple calculator.
// Topic        : Unit 1 - Basic console programs
// File         : Q01_Simple_Calculator.cs
// Source       : Practical journal: Q1_Calculator.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Calculator
{
    static void Main()
    {
        double a, b, result;
        int choice;
        char again;

        do
        {
            Console.WriteLine("----- Simple Calculator -----");
            Console.WriteLine("1. Addition");
            Console.WriteLine("2. Subtraction");
            Console.WriteLine("3. Multiplication");
            Console.WriteLine("4. Division");
            Console.Write("Enter your choice (1-4): ");
            choice = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter first number: ");
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter second number: ");
            b = Convert.ToDouble(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    result = a + b;
                    Console.WriteLine("Sum = " + result);
                    break;
                case 2:
                    result = a - b;
                    Console.WriteLine("Difference = " + result);
                    break;
                case 3:
                    result = a * b;
                    Console.WriteLine("Product = " + result);
                    break;
                case 4:
                    if (b == 0)
                    {
                        Console.WriteLine("Division by zero is not possible");
                    }
                    else
                    {
                        result = a / b;
                        Console.WriteLine("Quotient = " + result);
                    }
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }

            Console.Write("Do you want to continue (y/n)? ");
            again = Convert.ToChar(Console.ReadLine());
            Console.WriteLine();
        } while (again == 'y' || again == 'Y');
    }
}
