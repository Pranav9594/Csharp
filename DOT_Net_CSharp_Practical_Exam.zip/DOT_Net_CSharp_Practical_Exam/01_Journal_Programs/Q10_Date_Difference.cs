// ======================================================================
// Question No. : Q10
// Question     : Write a C# Program to find difference between Two Dates.
// Topic        : Unit 2 - Date and time
// File         : Q10_Date_Difference.cs
// Source       : Practical journal: Q10_DateDifference.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class DateDifference
{
    static void Main()
    {
        int d, m, y;

        Console.WriteLine("Enter first date");
        Console.Write("Day: ");
        d = Convert.ToInt32(Console.ReadLine());
        Console.Write("Month: ");
        m = Convert.ToInt32(Console.ReadLine());
        Console.Write("Year: ");
        y = Convert.ToInt32(Console.ReadLine());
        DateTime date1 = new DateTime(y, m, d);

        Console.WriteLine("Enter second date");
        Console.Write("Day: ");
        d = Convert.ToInt32(Console.ReadLine());
        Console.Write("Month: ");
        m = Convert.ToInt32(Console.ReadLine());
        Console.Write("Year: ");
        y = Convert.ToInt32(Console.ReadLine());
        DateTime date2 = new DateTime(y, m, d);

        // make date1 the earlier date
        if (date1 > date2)
        {
            DateTime temp = date1;
            date1 = date2;
            date2 = temp;
        }

        // total number of days between the two dates
        TimeSpan ts = date2 - date1;

        // complete months between the two dates
        int months = (date2.Year - date1.Year) * 12 + (date2.Month - date1.Month);
        if (date1.AddMonths(months) > date2)
        {
            months = months - 1;
        }

        // remaining days after the complete months
        int days = (date2 - date1.AddMonths(months)).Days;

        int years = months / 12;
        months = months % 12;

        Console.WriteLine("Total days = " + ts.Days);
        Console.WriteLine("Difference = " + years + " year(s), " + months + " month(s), " + days + " day(s)");
    }
}
