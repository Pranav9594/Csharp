// ======================================================================
// Question No. : Q03
// Question     : If you have two integers stored in variables var1 and var2, what Boolean test can you perform to see if one or the other (but not both) is greater than 10?
// Topic        : Unit 1 - Basic console programs
// File         : Q03_Boolean_Test_XOR.cs
// Source       : Practical journal: Q3_BooleanTest.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class BooleanTest
{
    static void Main()
    {
        int var1, var2;

        Console.Write("Enter value of var1: ");
        var1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter value of var2: ");
        var2 = Convert.ToInt32(Console.ReadLine());

        // one or the other (but not both) is greater than 10
        bool result = (var1 > 10 && var2 <= 10) || (var1 <= 10 && var2 > 10);

        // the same test using the exclusive OR operator
        bool result2 = (var1 > 10) ^ (var2 > 10);

        Console.WriteLine("Result using && and || : " + result);
        Console.WriteLine("Result using ^ operator : " + result2);

        if (result)
        {
            Console.WriteLine("Only one of the two values is greater than 10");
        }
        else
        {
            Console.WriteLine("Either both or none of the values are greater than 10");
        }
    }
}
