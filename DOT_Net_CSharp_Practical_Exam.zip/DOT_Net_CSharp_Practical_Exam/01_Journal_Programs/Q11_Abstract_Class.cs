// ======================================================================
// Question No. : Q11
// Question     : Write a program to demonstrate abstract class and abstract methods in C#.
// Topic        : Unit 3 - Classes and OOP
// File         : Q11_Abstract_Class.cs
// Source       : Practical journal: Q11_AbstractClass.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

abstract class Shape
{
    protected double area;

    public abstract void CalculateArea();   // abstract method

    public void Display()
    {
        Console.WriteLine("Area = " + area);
    }
}

class Rectangle : Shape
{
    private double length, breadth;

    public Rectangle(double l, double b)
    {
        length = l;
        breadth = b;
    }

    public override void CalculateArea()
    {
        area = length * breadth;
    }
}

class Circle : Shape
{
    private double radius;

    public Circle(double r)
    {
        radius = r;
    }

    public override void CalculateArea()
    {
        area = 3.14 * radius * radius;
    }
}

class Program
{
    static void Main()
    {
        Shape s;

        s = new Rectangle(5, 4);
        Console.WriteLine("Rectangle (length 5, breadth 4)");
        s.CalculateArea();
        s.Display();

        s = new Circle(3);
        Console.WriteLine("Circle (radius 3)");
        s.CalculateArea();
        s.Display();
    }
}
