// ======================================================================
// Question No. : Q09
// Question     : Write a C# Program to Check Whether the Entered Year is a Leap Year or Not.
// Topic        : Unit 2 - Date and time
// File         : Q09_Leap_Year.cs
// Source       : Practical journal: Q9_LeapYear.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class LeapYear
{
    static void Main()
    {
        int year;

        Console.Write("Enter a year: ");
        year = Convert.ToInt32(Console.ReadLine());

        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
        {
            Console.WriteLine(year + " is a Leap Year");
        }
        else
        {
            Console.WriteLine(year + " is not a Leap Year");
        }
    }
}
