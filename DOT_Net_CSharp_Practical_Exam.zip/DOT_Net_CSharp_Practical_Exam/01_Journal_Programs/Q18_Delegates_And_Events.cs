// ======================================================================
// Question No. : Q18
// Question     : Develop a C# program to implement (a) Delegates (b) Events.
// Topic        : Unit 6 - Threads, delegates and events
// File         : Q18_Delegates_And_Events.cs
// Source       : Practical journal: Q18_DelegatesAndEvents.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

// ---------- (a) Delegates ----------
delegate int Operation(int x, int y);

class Calculator
{
    public static int Add(int x, int y)
    {
        return x + y;
    }

    public static int Multiply(int x, int y)
    {
        return x * y;
    }
}

// ---------- (b) Events ----------
delegate void AlarmHandler(string message);

class Alarm
{
    public event AlarmHandler Ring;

    public void Start()
    {
        Console.WriteLine("Alarm started...");
        if (Ring != null)
        {
            Ring("Wake up! Time is over.");
        }
    }
}

class Person
{
    private string name;

    public Person(string n)
    {
        name = n;
    }

    public void Wake(string message)
    {
        Console.WriteLine(name + " received the alarm : " + message);
    }
}

class Program
{
    static void Main()
    {
        // Delegates
        Console.WriteLine("----- Delegates -----");
        Operation op;

        op = new Operation(Calculator.Add);
        Console.WriteLine("Addition = " + op(10, 5));

        op = new Operation(Calculator.Multiply);
        Console.WriteLine("Multiplication = " + op(10, 5));

        // Events
        Console.WriteLine();
        Console.WriteLine("----- Events -----");
        Alarm alarm = new Alarm();
        Person p1 = new Person("Amit");
        Person p2 = new Person("Neha");

        alarm.Ring += new AlarmHandler(p1.Wake);
        alarm.Ring += new AlarmHandler(p2.Wake);

        alarm.Start();
    }
}
