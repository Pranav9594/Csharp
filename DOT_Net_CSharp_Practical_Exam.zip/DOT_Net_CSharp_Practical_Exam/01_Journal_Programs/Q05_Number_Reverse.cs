// ======================================================================
// Question No. : Q05
// Question     : Write a C# Program to Get a Number and Display the Number with its Reverse.
// Topic        : Unit 1 - Basic console programs
// File         : Q05_Number_Reverse.cs
// Source       : Practical journal: Q5_NumberReverse.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class NumberReverse
{
    static void Main()
    {
        int num, temp;
        long rev = 0;
        int digit;

        Console.Write("Enter a number: ");
        num = Convert.ToInt32(Console.ReadLine());

        temp = num;
        if (temp < 0)
        {
            temp = -temp;
        }

        while (temp > 0)
        {
            digit = temp % 10;
            rev = rev * 10 + digit;
            temp = temp / 10;
        }

        if (num < 0)
        {
            rev = -rev;
        }

        Console.WriteLine("Number = " + num);
        Console.WriteLine("Reverse = " + rev);
    }
}
