-- Run this script inside the STUDENT database (STUDENT.mdf)
-- Course table
CREATE TABLE Course
(
    C_ID     int          NOT NULL PRIMARY KEY,
    C_Name   varchar(50)  NOT NULL
);

-- Student table
CREATE TABLE Student
(
    RollNo         int          NOT NULL PRIMARY KEY,
    S_Name         varchar(50)  NOT NULL,
    Address        varchar(100),
    C_ID           int          NOT NULL FOREIGN KEY REFERENCES Course(C_ID),
    Admissionyear  int          NOT NULL
);

-- Optional sample data for testing
INSERT INTO Course VALUES (1, 'BCA');
INSERT INTO Course VALUES (2, 'BBA');
INSERT INTO Student VALUES (101, 'Rahul Shah', 'Mumbai', 1, 2022);
INSERT INTO Student VALUES (102, 'Priya Mehta', 'Thane', 1, 2023);
INSERT INTO Student VALUES (103, 'Amit Patil', 'Pune', 2, 2022);
