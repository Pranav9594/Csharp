namespace StudentApplication
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblCourseId = new System.Windows.Forms.Label();
            this.txtCourseId = new System.Windows.Forms.TextBox();
            this.lblCourseName = new System.Windows.Forms.Label();
            this.txtCourseName = new System.Windows.Forms.TextBox();
            this.btnAddCourse = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblRollNo = new System.Windows.Forms.Label();
            this.txtRollNo = new System.Windows.Forms.TextBox();
            this.lblStudentName = new System.Windows.Forms.Label();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblStudentCourseId = new System.Windows.Forms.Label();
            this.txtStudentCourseId = new System.Windows.Forms.TextBox();
            this.lblAdmissionYear = new System.Windows.Forms.Label();
            this.txtAdmissionYear = new System.Windows.Forms.TextBox();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblSearchCourseId = new System.Windows.Forms.Label();
            this.txtSearchCourseId = new System.Windows.Forms.TextBox();
            this.btnShowByCourse = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lblSearchYear = new System.Windows.Forms.Label();
            this.txtSearchYear = new System.Windows.Forms.TextBox();
            this.btnShowByYear = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(500, 330);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblCourseId);
            this.tabPage1.Controls.Add(this.txtCourseId);
            this.tabPage1.Controls.Add(this.lblCourseName);
            this.tabPage1.Controls.Add(this.txtCourseName);
            this.tabPage1.Controls.Add(this.btnAddCourse);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(492, 304);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "New Course";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblCourseId
            // 
            this.lblCourseId.AutoSize = true;
            this.lblCourseId.Location = new System.Drawing.Point(20, 30);
            this.lblCourseId.Name = "lblCourseId";
            this.lblCourseId.TabIndex = 0;
            this.lblCourseId.Text = "Course ID";
            // 
            // txtCourseId
            // 
            this.txtCourseId.Location = new System.Drawing.Point(140, 27);
            this.txtCourseId.Name = "txtCourseId";
            this.txtCourseId.Size = new System.Drawing.Size(150, 20);
            this.txtCourseId.TabIndex = 1;
            // 
            // lblCourseName
            // 
            this.lblCourseName.AutoSize = true;
            this.lblCourseName.Location = new System.Drawing.Point(20, 70);
            this.lblCourseName.Name = "lblCourseName";
            this.lblCourseName.TabIndex = 2;
            this.lblCourseName.Text = "Course Name";
            // 
            // txtCourseName
            // 
            this.txtCourseName.Location = new System.Drawing.Point(140, 67);
            this.txtCourseName.Name = "txtCourseName";
            this.txtCourseName.Size = new System.Drawing.Size(220, 20);
            this.txtCourseName.TabIndex = 3;
            // 
            // btnAddCourse
            // 
            this.btnAddCourse.UseVisualStyleBackColor = true;
            this.btnAddCourse.Location = new System.Drawing.Point(140, 110);
            this.btnAddCourse.Name = "btnAddCourse";
            this.btnAddCourse.Size = new System.Drawing.Size(100, 28);
            this.btnAddCourse.TabIndex = 4;
            this.btnAddCourse.Text = "Add Course";
            this.btnAddCourse.Click += new System.EventHandler(this.btnAddCourse_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblRollNo);
            this.tabPage2.Controls.Add(this.txtRollNo);
            this.tabPage2.Controls.Add(this.lblStudentName);
            this.tabPage2.Controls.Add(this.txtStudentName);
            this.tabPage2.Controls.Add(this.lblAddress);
            this.tabPage2.Controls.Add(this.txtAddress);
            this.tabPage2.Controls.Add(this.lblStudentCourseId);
            this.tabPage2.Controls.Add(this.txtStudentCourseId);
            this.tabPage2.Controls.Add(this.lblAdmissionYear);
            this.tabPage2.Controls.Add(this.txtAdmissionYear);
            this.tabPage2.Controls.Add(this.btnAddStudent);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(492, 304);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "New Student";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblRollNo
            // 
            this.lblRollNo.AutoSize = true;
            this.lblRollNo.Location = new System.Drawing.Point(20, 30);
            this.lblRollNo.Name = "lblRollNo";
            this.lblRollNo.TabIndex = 0;
            this.lblRollNo.Text = "Roll No";
            // 
            // txtRollNo
            // 
            this.txtRollNo.Location = new System.Drawing.Point(140, 27);
            this.txtRollNo.Name = "txtRollNo";
            this.txtRollNo.Size = new System.Drawing.Size(150, 20);
            this.txtRollNo.TabIndex = 1;
            // 
            // lblStudentName
            // 
            this.lblStudentName.AutoSize = true;
            this.lblStudentName.Location = new System.Drawing.Point(20, 65);
            this.lblStudentName.Name = "lblStudentName";
            this.lblStudentName.TabIndex = 2;
            this.lblStudentName.Text = "Student Name";
            // 
            // txtStudentName
            // 
            this.txtStudentName.Location = new System.Drawing.Point(140, 62);
            this.txtStudentName.Name = "txtStudentName";
            this.txtStudentName.Size = new System.Drawing.Size(220, 20);
            this.txtStudentName.TabIndex = 3;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(20, 100);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.TabIndex = 4;
            this.lblAddress.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(140, 97);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(220, 20);
            this.txtAddress.TabIndex = 5;
            // 
            // lblStudentCourseId
            // 
            this.lblStudentCourseId.AutoSize = true;
            this.lblStudentCourseId.Location = new System.Drawing.Point(20, 135);
            this.lblStudentCourseId.Name = "lblStudentCourseId";
            this.lblStudentCourseId.TabIndex = 6;
            this.lblStudentCourseId.Text = "Course ID";
            // 
            // txtStudentCourseId
            // 
            this.txtStudentCourseId.Location = new System.Drawing.Point(140, 132);
            this.txtStudentCourseId.Name = "txtStudentCourseId";
            this.txtStudentCourseId.Size = new System.Drawing.Size(150, 20);
            this.txtStudentCourseId.TabIndex = 7;
            // 
            // lblAdmissionYear
            // 
            this.lblAdmissionYear.AutoSize = true;
            this.lblAdmissionYear.Location = new System.Drawing.Point(20, 170);
            this.lblAdmissionYear.Name = "lblAdmissionYear";
            this.lblAdmissionYear.TabIndex = 8;
            this.lblAdmissionYear.Text = "Admission Year";
            // 
            // txtAdmissionYear
            // 
            this.txtAdmissionYear.Location = new System.Drawing.Point(140, 167);
            this.txtAdmissionYear.Name = "txtAdmissionYear";
            this.txtAdmissionYear.Size = new System.Drawing.Size(150, 20);
            this.txtAdmissionYear.TabIndex = 9;
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.UseVisualStyleBackColor = true;
            this.btnAddStudent.Location = new System.Drawing.Point(140, 210);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(100, 28);
            this.btnAddStudent.TabIndex = 10;
            this.btnAddStudent.Text = "Add Student";
            this.btnAddStudent.Click += new System.EventHandler(this.btnAddStudent_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lblSearchCourseId);
            this.tabPage3.Controls.Add(this.txtSearchCourseId);
            this.tabPage3.Controls.Add(this.btnShowByCourse);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(492, 304);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Students by Course";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lblSearchCourseId
            // 
            this.lblSearchCourseId.AutoSize = true;
            this.lblSearchCourseId.Location = new System.Drawing.Point(20, 20);
            this.lblSearchCourseId.Name = "lblSearchCourseId";
            this.lblSearchCourseId.TabIndex = 0;
            this.lblSearchCourseId.Text = "Course ID";
            // 
            // txtSearchCourseId
            // 
            this.txtSearchCourseId.Location = new System.Drawing.Point(110, 17);
            this.txtSearchCourseId.Name = "txtSearchCourseId";
            this.txtSearchCourseId.Size = new System.Drawing.Size(120, 20);
            this.txtSearchCourseId.TabIndex = 1;
            // 
            // btnShowByCourse
            // 
            this.btnShowByCourse.UseVisualStyleBackColor = true;
            this.btnShowByCourse.Location = new System.Drawing.Point(250, 13);
            this.btnShowByCourse.Name = "btnShowByCourse";
            this.btnShowByCourse.Size = new System.Drawing.Size(110, 28);
            this.btnShowByCourse.TabIndex = 2;
            this.btnShowByCourse.Text = "Show Students";
            this.btnShowByCourse.Click += new System.EventHandler(this.btnShowByCourse_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Location = new System.Drawing.Point(20, 55);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(450, 240);
            this.dataGridView1.TabIndex = 3;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.lblSearchYear);
            this.tabPage4.Controls.Add(this.txtSearchYear);
            this.tabPage4.Controls.Add(this.btnShowByYear);
            this.tabPage4.Controls.Add(this.dataGridView2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(492, 304);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Students by Year";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // lblSearchYear
            // 
            this.lblSearchYear.AutoSize = true;
            this.lblSearchYear.Location = new System.Drawing.Point(20, 20);
            this.lblSearchYear.Name = "lblSearchYear";
            this.lblSearchYear.TabIndex = 0;
            this.lblSearchYear.Text = "Admission Year";
            // 
            // txtSearchYear
            // 
            this.txtSearchYear.Location = new System.Drawing.Point(120, 17);
            this.txtSearchYear.Name = "txtSearchYear";
            this.txtSearchYear.Size = new System.Drawing.Size(110, 20);
            this.txtSearchYear.TabIndex = 1;
            // 
            // btnShowByYear
            // 
            this.btnShowByYear.UseVisualStyleBackColor = true;
            this.btnShowByYear.Location = new System.Drawing.Point(250, 13);
            this.btnShowByYear.Name = "btnShowByYear";
            this.btnShowByYear.Size = new System.Drawing.Size(110, 28);
            this.btnShowByYear.TabIndex = 2;
            this.btnShowByYear.Text = "Show Students";
            this.btnShowByYear.Click += new System.EventHandler(this.btnShowByYear_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.Location = new System.Drawing.Point(20, 55);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(450, 240);
            this.dataGridView2.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 354);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Management";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblCourseId;
        private System.Windows.Forms.TextBox txtCourseId;
        private System.Windows.Forms.Label lblCourseName;
        private System.Windows.Forms.TextBox txtCourseName;
        private System.Windows.Forms.Button btnAddCourse;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblRollNo;
        private System.Windows.Forms.TextBox txtRollNo;
        private System.Windows.Forms.Label lblStudentName;
        private System.Windows.Forms.TextBox txtStudentName;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblStudentCourseId;
        private System.Windows.Forms.TextBox txtStudentCourseId;
        private System.Windows.Forms.Label lblAdmissionYear;
        private System.Windows.Forms.TextBox txtAdmissionYear;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label lblSearchCourseId;
        private System.Windows.Forms.TextBox txtSearchCourseId;
        private System.Windows.Forms.Button btnShowByCourse;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label lblSearchYear;
        private System.Windows.Forms.TextBox txtSearchYear;
        private System.Windows.Forms.Button btnShowByYear;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}
