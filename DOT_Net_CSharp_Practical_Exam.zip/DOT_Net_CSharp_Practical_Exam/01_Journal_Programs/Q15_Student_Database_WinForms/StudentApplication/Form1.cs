using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace StudentApplication
{
    public partial class Form1 : Form
    {
        SqlConnection cn;

        public Form1()
        {
            InitializeComponent();
            cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\STUDENT.mdf;Integrated Security=True;User Instance=True");
        }

        // 1. Entering new course details
        private void btnAddCourse_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Course values (@id,@nm)";
                cmd.Connection = cn;

                SqlParameter p1, p2;

                p1 = new SqlParameter();
                p1.ParameterName = "id";
                p1.Value = Int32.Parse(txtCourseId.Text);

                p2 = new SqlParameter();
                p2.ParameterName = "nm";
                p2.Value = txtCourseName.Text;

                cmd.Parameters.Add(p1);
                cmd.Parameters.Add(p2);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Course Inserted Successfully");

                txtCourseId.Text = "";
                txtCourseName.Text = "";
            }
            catch (FormatException)
            {
                MessageBox.Show("Course ID must be a number");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database Error : " + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        // 2. Entering new student details
        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Student values (@roll,@nm,@addr,@cid,@yr)";
                cmd.Connection = cn;

                SqlParameter p1, p2, p3, p4, p5;

                p1 = new SqlParameter();
                p1.ParameterName = "roll";
                p1.Value = Int32.Parse(txtRollNo.Text);

                p2 = new SqlParameter();
                p2.ParameterName = "nm";
                p2.Value = txtStudentName.Text;

                p3 = new SqlParameter();
                p3.ParameterName = "addr";
                p3.Value = txtAddress.Text;

                p4 = new SqlParameter();
                p4.ParameterName = "cid";
                p4.Value = Int32.Parse(txtStudentCourseId.Text);

                p5 = new SqlParameter();
                p5.ParameterName = "yr";
                p5.Value = Int32.Parse(txtAdmissionYear.Text);

                cmd.Parameters.Add(p1);
                cmd.Parameters.Add(p2);
                cmd.Parameters.Add(p3);
                cmd.Parameters.Add(p4);
                cmd.Parameters.Add(p5);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Student Inserted Successfully");

                txtRollNo.Text = "";
                txtStudentName.Text = "";
                txtAddress.Text = "";
                txtStudentCourseId.Text = "";
                txtAdmissionYear.Text = "";
            }
            catch (FormatException)
            {
                MessageBox.Show("Roll No, Course ID and Admission Year must be numbers");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database Error : " + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        // 3. Display students of a particular course
        private void btnShowByCourse_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();

                SqlDataAdapter da = new SqlDataAdapter("select s.RollNo, s.S_Name, s.Address, s.C_ID, c.C_Name, s.Admissionyear from Student s, Course c where s.C_ID = c.C_ID and s.C_ID = @cid", cn);
                da.SelectCommand.Parameters.AddWithValue("@cid", Int32.Parse(txtSearchCourseId.Text));

                DataSet ds = new DataSet();
                da.Fill(ds, "abc");
                DataTable dt = new DataTable();
                dt = ds.Tables["abc"];
                dataGridView1.DataSource = dt;

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No students found for this course");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Course ID must be a number");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database Error : " + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        // 4. Display students who took admission in a particular year
        private void btnShowByYear_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();

                SqlDataAdapter da = new SqlDataAdapter("select s.RollNo, s.S_Name, s.Address, s.C_ID, c.C_Name, s.Admissionyear from Student s, Course c where s.C_ID = c.C_ID and s.Admissionyear = @yr", cn);
                da.SelectCommand.Parameters.AddWithValue("@yr", Int32.Parse(txtSearchYear.Text));

                DataSet ds = new DataSet();
                da.Fill(ds, "abc");
                DataTable dt = new DataTable();
                dt = ds.Tables["abc"];
                dataGridView2.DataSource = dt;

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No students found for this year");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Admission Year must be a number");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database Error : " + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
