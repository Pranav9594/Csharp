// ======================================================================
// Question No. : Q02
// Question     : Write a console application that obtains four int values from the user and displays the product.
// Topic        : Unit 1 - Basic console programs
// File         : Q02_Product_Of_Four_Integers.cs
// Source       : Practical journal: Q2_Product.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Product
{
    static void Main()
    {
        int a, b, c, d;
        long product;

        Console.Write("Enter first integer: ");
        a = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter second integer: ");
        b = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter third integer: ");
        c = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter fourth integer: ");
        d = Convert.ToInt32(Console.ReadLine());

        product = (long)a * b * c * d;

        Console.WriteLine("Product of " + a + ", " + b + ", " + c + " and " + d + " = " + product);
    }
}
