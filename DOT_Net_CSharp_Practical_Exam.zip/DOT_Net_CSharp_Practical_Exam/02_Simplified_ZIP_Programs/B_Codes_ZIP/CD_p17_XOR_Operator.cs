// ======================================================================
// Question No. : CD-P17
// Question     : Write a C# program to test whether exactly one of two integers is greater than 10 using the XOR operator.
// Topic        : Operators
// File         : CD_p17_XOR_Operator.cs
// Source       : Codes.zip -> p17.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int var1 = 1;
        int var2 = 12;

        bool result = (var1 > 10) ^ (var2 > 10);

        //				0           ^         1  = 1
        Console.WriteLine("Result: " + result);
    }
}
