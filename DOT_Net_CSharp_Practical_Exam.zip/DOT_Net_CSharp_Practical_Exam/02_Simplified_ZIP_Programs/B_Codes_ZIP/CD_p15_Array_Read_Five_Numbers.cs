// ======================================================================
// Question No. : CD-P15
// Question     : Write a C# program to read five numbers into an array and display them.
// Topic        : Arrays
// File         : CD_p15_Array_Read_Five_Numbers.cs
// Source       : Codes.zip -> p15.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main (String []ar)
    {
        int []a = new int [5];
        int i;
        Console.WriteLine("Enter Five Numbers ");
        for (i=0;i<5;i++)
        {
            a[i] = Int32.Parse (Console.ReadLine());
        }
        Console.WriteLine("Given Five Numbers ");
        for (i=0;i<5;i++)
        {
            Console.WriteLine(a[i]);
        }
    }
}
