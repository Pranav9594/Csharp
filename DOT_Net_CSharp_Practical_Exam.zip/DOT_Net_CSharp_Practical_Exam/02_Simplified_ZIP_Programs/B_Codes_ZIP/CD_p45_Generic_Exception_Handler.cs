// ======================================================================
// Question No. : CD-P45
// Question     : Write a C# program to demonstrate a generic exception handler.
// Topic        : Exception handling
// File         : CD_p45_Generic_Exception_Handler.cs
// Source       : Codes.zip -> p45.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
class Program
{
    static void Main(string[] args)
    {
        try
        {
            int[] myNumbers = {1, 2, 3};
            Console.WriteLine(myNumbers[10]);
        }
        catch (Exception) //Generic Exception Handler.
        {
            Console.WriteLine("Something went wrong.");
        }
    }
}
