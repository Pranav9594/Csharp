// ======================================================================
// Question No. : CD-P01
// Question     : Write a C# program to display Hello World.
// Topic        : Basics
// File         : CD_p01_Hello_World.cs
// Source       : Codes.zip -> p1.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        Console.WriteLine("Hello World");
    }
}
