// ======================================================================
// Question No. : CD-P07
// Question     : Write a C# program to read four integers and display their product.
// Topic        : Operators
// File         : CD_p07_Product_Of_Four_Numbers.cs
// Source       : Codes.zip -> p7.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int a,b,c,d,mul;
        Console.WriteLine ("Enter 1 Number " );
        a = Int32.Parse(Console.ReadLine());
        Console.WriteLine ("Enter 2 Number " );
        b = Int32.Parse(Console.ReadLine());
        Console.WriteLine ("Enter 3 Number " );
        c = Int32.Parse(Console.ReadLine());
        Console.WriteLine ("Enter 4 Number " );
        d = Int32.Parse(Console.ReadLine());
        mul = a * b * c * d;
        Console.WriteLine ("Multiplication " + mul);
    }
}
