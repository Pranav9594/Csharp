// ======================================================================
// Question No. : CD-P12
// Question     : Write a C# program to display a welcome message using a command line argument.
// Topic        : Command line arguments
// File         : CD_p12_Command_Line_Name.cs
// Source       : Codes.zip -> p12.cs
// Run with     : command line arguments (Project > Properties > Debug).
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main (String []ar)
    {
        String str;
        str = ar[0];
        Console.WriteLine ("Welcome " + str);
    }
}
