// ======================================================================
// Question No. : CD-P35
// Question     : Write a C# program to implement two interfaces in one class.
// Topic        : OOP - Interface
// File         : CD_p35_Multiple_Interfaces.cs
// Source       : Codes.zip -> p35.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

interface i1
{
    void m1();
}

interface i2
{
    void m2();
}

class UseInterface : i1,i2
{
    public void m1()
    {
        Console.WriteLine ("Method from Interface-1");
    }
    public void m2()
    {
        Console.WriteLine ("Method from Interface-2");
    }
}

class Sample
{
    public static void Main ()
    {
        UseInterface obj = new UseInterface();
        obj.m1();
        obj.m2();
    }
}
