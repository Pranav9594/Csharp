// ======================================================================
// Question No. : CD-P19
// Question     : Write a C# program to display a number with its digits reversed.
// Topic        : Control statements
// File         : CD_p19_Number_Reverse.cs
// Source       : Codes.zip -> p19.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int n,r,sum=0;
        Console.WriteLine("Enter any Number ");
        n = Int32.Parse(Console.ReadLine());
        while ( n > 0 )
        {
            r = n % 10;
            sum = sum*10 + r;
            n = n / 10;
        }
        Console.WriteLine("Sum is " + sum);
    }
}
