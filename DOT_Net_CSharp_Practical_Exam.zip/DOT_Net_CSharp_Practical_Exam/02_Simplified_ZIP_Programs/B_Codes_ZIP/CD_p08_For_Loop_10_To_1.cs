// ======================================================================
// Question No. : CD-P08
// Question     : Write a C# program to display numbers from 10 to 1 using a for loop.
// Topic        : Control statements
// File         : CD_p08_For_Loop_10_To_1.cs
// Source       : Codes.zip -> p8.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int i;
        for (i=10;i>=1;i--)
        {
            Console.WriteLine (i);
        }
    }
}
