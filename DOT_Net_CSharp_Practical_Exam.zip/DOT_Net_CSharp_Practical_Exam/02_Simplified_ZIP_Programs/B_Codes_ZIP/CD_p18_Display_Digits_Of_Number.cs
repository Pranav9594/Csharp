// ======================================================================
// Question No. : CD-P18
// Question     : Write a C# program to display the digits of a number one by one (from the last digit).
// Topic        : Control statements
// File         : CD_p18_Display_Digits_Of_Number.cs
// Source       : Codes.zip -> p18.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int n,r;
        Console.WriteLine("Enter any Number ");
        n = Int32.Parse(Console.ReadLine());
        while ( n > 0 )
        {
            r = n % 10;
            Console.WriteLine(r);
            n = n / 10;
        }

    }
}
