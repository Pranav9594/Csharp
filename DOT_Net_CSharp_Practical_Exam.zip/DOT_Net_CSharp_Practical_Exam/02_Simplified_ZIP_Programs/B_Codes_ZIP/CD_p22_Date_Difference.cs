// ======================================================================
// Question No. : CD-P22
// Question     : Write a C# program to find the difference between two dates.
// Topic        : Date and time
// File         : CD_p22_Date_Difference.cs
// Source       : Codes.zip -> p22.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter First Date (dd/mm/yyyy): ");
        DateTime date1 = Convert.ToDateTime(Console.ReadLine());

        Console.Write("Enter Second Date (dd/mm/yyyy): ");
        DateTime date2 = Convert.ToDateTime(Console.ReadLine());

        TimeSpan difference = date2 - date1;

        Console.WriteLine("Difference in Days: " + difference.Days / 365 + " " + ( difference.Days % 365 ) / 12 + " " + ( difference.Days % 365 ) % 12 );
    }
}
