// ======================================================================
// Question No. : CD-P16
// Question     : Write a C# program to display the elements of an initialised array.
// Topic        : Arrays
// File         : CD_p16_Array_Initialised.cs
// Source       : Codes.zip -> p16.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main (String []ar)
    {
        int []a = {12,23,34};
        int i;
        Console.WriteLine("Given Five Numbers ");
        for (i=0;i<a.Length;i++)
        {
            Console.WriteLine(a[i]);
        }
    }
}
