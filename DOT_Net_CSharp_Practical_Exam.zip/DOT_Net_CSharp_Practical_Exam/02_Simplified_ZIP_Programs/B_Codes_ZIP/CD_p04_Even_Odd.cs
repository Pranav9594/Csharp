// ======================================================================
// Question No. : CD-P04
// Question     : Write a C# program to check whether a number is even or odd.
// Topic        : Control statements
// File         : CD_p04_Even_Odd.cs
// Source       : Codes.zip -> p4.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int n;
        Console.WriteLine("Enter a Number ");
        n = Int32.Parse(Console.ReadLine());
        if ( n % 2 == 0)
        {
            Console.WriteLine ("Number is Even ");
        }
        else
        {
            Console.WriteLine ("Number is Odd ");
        }
    }
}
