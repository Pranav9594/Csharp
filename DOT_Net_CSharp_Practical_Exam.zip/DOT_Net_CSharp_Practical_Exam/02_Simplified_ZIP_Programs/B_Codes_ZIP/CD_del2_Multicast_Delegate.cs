// ======================================================================
// Question No. : CD-DEL2
// Question     : Write a C# program to demonstrate a multicast delegate.
// Topic        : Delegates and events
// File         : CD_del2_Multicast_Delegate.cs
// Source       : Codes.zip -> del2.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
delegate int NumberChanger(int n);

class TestDelegate {
    static int num = 10;

    public static int AddNum(int p) {
        num += p;
        return num;
    }
    public static int MultNum(int q) {
        num *= q;
        return num;
    }
    public static int getNum() {
        return num;
    }
    static void Main(string[] args) {
        //create delegate instances

        NumberChanger nc1 = new NumberChanger(AddNum);
        NumberChanger nc2 = new NumberChanger(MultNum);
        NumberChanger nc;
        nc = nc1;
        nc+=nc2;
        nc (10);
        Console.WriteLine("Value of Num: {0}", getNum());

    }
}
