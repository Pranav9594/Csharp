// ======================================================================
// Question No. : CD-P38
// Question     : Write a C# program to handle the divide by zero exception.
// Topic        : Exception handling
// File         : CD_p38_Exception_Divide_By_Zero.cs
// Source       : Codes.zip -> p38.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int result=0;
        try
        {
            Console.Write("Enter first number: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter second number: ");
            int b = Convert.ToInt32(Console.ReadLine());

            result = a / b;  // Possible DivideByZeroException
        }
        catch (DivideByZeroException ex)
        {
            Console.WriteLine("Error: Cannot divide by zero.");
            Console.WriteLine("Details: " + ex.Message);
        }
        Console.WriteLine("Result: " + result);

    }
}
