// ======================================================================
// Question No. : CD-P29
// Question     : Write a C# program to demonstrate default, parameterised and copy constructors and a destructor.
// Topic        : OOP - Constructor
// File         : CD_p29_Constructors_Student.cs
// Source       : Codes.zip -> p29.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Student
{
    private int rno;
    private String name;

    public Student() //Default Constructor
    {
        rno = 10;
        name = "Alok";
    }
    public Student(int r,String n) //Parameterised Constructor
    {
        rno = r;
        name = n;
    }
    public Student(Student S) //Copy Constructor
    {
        rno = S.rno;
        name = S.name;
    }
    public void setData ()
    {
        Console.WriteLine ("Enter Roll No ");
        rno = Int32.Parse (Console.ReadLine());
        Console.WriteLine ("Enter Name ");
        name = Console.ReadLine();
    }

    public void putData ()
    {
        Console.WriteLine ("Roll No "+ rno);
        Console.WriteLine ("Name   " +name);
    }

    ~Student()
    {
        Console.WriteLine("Distructor ");
    }

}

class Sample
{
    public static void Main ()
    {
        Student S1 = new Student();
        Student S2 = new Student(1,"Nitin");
        Student S3 = new Student(S2);

        S1.putData ();
        S2.putData ();
        S3.putData();
    }
}
