// ======================================================================
// Question No. : CD-P32
// Question     : Find the sum of all the elements present in a jagged array of 3 inner arrays.
// Topic        : Arrays
// File         : CD_p32_Jagged_Array_Sum.cs
// Source       : Codes.zip -> p32.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int [][] jaggedArray = new int[3][];

        jaggedArray[0] = new int[] { 1, 2, 3 };
        jaggedArray[1] = new int[] { 4, 5 };
        jaggedArray[2] = new int[] { 6, 7, 8, 9 };

        int sum = 0;

        for (int i = 0; i < jaggedArray.Length; i++)
        {
            for (int j = 0; j < jaggedArray[i].Length; j++)
            {
                sum += jaggedArray[i][j];
            }
        }

        Console.WriteLine("Sum of all elements: " + sum);
    }
}
