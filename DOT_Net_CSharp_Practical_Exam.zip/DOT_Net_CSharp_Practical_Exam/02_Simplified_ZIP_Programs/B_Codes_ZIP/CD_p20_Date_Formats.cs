// ======================================================================
// Question No. : CD-P20
// Question     : Write a C# program to display the current date in various formats.
// Topic        : Date and time
// File         : CD_p20_Date_Formats.cs
// Source       : Codes.zip -> p20.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        DateTime today = DateTime.Now;

        Console.WriteLine("Default Format: " + today);
        Console.WriteLine("Short Date: " + today.ToShortDateString());
        Console.WriteLine("Long Date: " + today.ToLongDateString());
        Console.WriteLine("Short Time: " + today.ToShortTimeString());
        Console.WriteLine("Long Time: " + today.ToLongTimeString());

        Console.WriteLine("Custom Format 1: " + today.ToString("dd/MM/yyyy"));
        Console.WriteLine("Custom Format 2: " + today.ToString("MMMM dd, yyyy"));
        Console.WriteLine("Custom Format 3: " + today.ToString("dddd"));
    }
}
