// ======================================================================
// Question No. : CD-P10
// Question     : Write a C# program to display numbers from 10 to 1 using a while loop.
// Topic        : Control statements
// File         : CD_p10_While_Loop_10_To_1.cs
// Source       : Codes.zip -> p10.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int i;
        i=10;
        while (i>=1)
        {
            Console.WriteLine (i);
            i--;
        }
    }
}
