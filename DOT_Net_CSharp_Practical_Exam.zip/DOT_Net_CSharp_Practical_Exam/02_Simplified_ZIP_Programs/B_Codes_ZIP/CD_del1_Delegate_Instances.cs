// ======================================================================
// Question No. : CD-DEL1
// Question     : Write a C# program to demonstrate delegates.
// Topic        : Delegates and events
// File         : CD_del1_Delegate_Instances.cs
// Source       : Codes.zip -> del1.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

delegate int test (int p);

class TestDelegate {
    public static int num=0;

    public static int AddNum(int p) {
        num = num + p;
        return num;
    }
    public static int MulNum(int p) {
        num = num * p;
        return num ;
    }

    public static int GetNum() {
        return num ;
    }

    static void Main(string[] args) {
        //create delegate instances
        test nc1 = new test(AddNum);
        test nc2 = new test(MulNum);
        nc1(10);
        Console.WriteLine(GetNum());
        nc2(5);
        Console.WriteLine(GetNum());
    }
}
