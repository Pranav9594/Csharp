// ======================================================================
// Question No. : CD-EVENTEX
// Question     : Write a C# program to demonstrate events.
// Topic        : Delegates and events
// File         : CD_eventex_Event_Example.cs
// Source       : Codes.zip -> eventex.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

public delegate string MyDel(string str);
class EventProgram {
    event MyDel MyEvent;
    public EventProgram() {
        MyEvent += new MyDel(WelcomeUser);
    }
    public string WelcomeUser(string username) {
        return "Welcome " + username;
    }
    static void Main(string[] args) {
        EventProgram obj1 = new EventProgram();
        string result = obj1.MyEvent("Alok");
        Console.WriteLine(result);
    }
}
