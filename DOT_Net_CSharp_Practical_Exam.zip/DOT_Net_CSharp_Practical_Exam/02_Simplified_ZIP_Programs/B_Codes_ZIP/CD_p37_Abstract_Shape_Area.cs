// ======================================================================
// Question No. : CD-P37
// Question     : Write a C# program to find the area of a circle and a rectangle using an abstract class.
// Topic        : OOP - Abstract class
// File         : CD_p37_Abstract_Shape_Area.cs
// Source       : Codes.zip -> p37.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

abstract class Shape
{
    protected double area;
    public abstract void Area();   // Abstract method
    public void Display()
    {
        Console.WriteLine("Shape class method "+area);
    }
}

class Circle : Shape
{
    private double radius;
    public Circle(double r)
    {
        radius = r;
    }
    public override void Area()
    {
        area =  Math.PI * radius * radius;
    }
}

class Rectangle : Shape
{
    public double length, breadth;

    public Rectangle(double l, double b)
    {
        length = l;
        breadth = b;
    }

    public override void Area()
    {
        area = length*breadth;
    }

}

class Program
{
    static void Main()
    {
        Shape s = new Circle(5);
        s.Area();
        s.Display();
        s = new Rectangle(5,6);
        s.Area();
        s.Display();
    }
}
