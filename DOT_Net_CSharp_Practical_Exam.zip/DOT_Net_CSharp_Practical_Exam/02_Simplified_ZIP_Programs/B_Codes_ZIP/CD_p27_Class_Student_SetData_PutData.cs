// ======================================================================
// Question No. : CD-P27
// Question     : Write a C# program to create a Student class with methods to read and display roll number and name.
// Topic        : OOP - Class
// File         : CD_p27_Class_Student_SetData_PutData.cs
// Source       : Codes.zip -> p27.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Student
{
    private int rno;
    private String name;

    public void setData ()
    {
        Console.WriteLine ("Enter Roll No ");
        rno = Int32.Parse (Console.ReadLine());
        Console.WriteLine ("Enter Name ");
        name = Console.ReadLine();
    }

    public void putData ()
    {
        Console.WriteLine ("Roll No "+ rno);
        Console.WriteLine ("Name   " +name);
    }
}

class Sample
{
    public static void Main ()
    {
        Student S = new Student();
        S.setData();
        S.putData ();
    }
}
