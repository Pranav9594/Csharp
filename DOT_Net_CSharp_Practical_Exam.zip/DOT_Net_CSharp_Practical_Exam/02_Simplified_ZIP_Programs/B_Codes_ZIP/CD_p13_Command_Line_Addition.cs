// ======================================================================
// Question No. : CD-P13
// Question     : Write a C# program to add two numbers passed as command line arguments.
// Topic        : Command line arguments
// File         : CD_p13_Command_Line_Addition.cs
// Source       : Codes.zip -> p13.cs
// Run with     : command line arguments (Project > Properties > Debug).
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main (String []ar)
    {
        int a,b,c;
        a = Int32.Parse(ar[0]);
        b = Int32.Parse(ar[1]);
        c = a + b;
        Console.WriteLine ("Addition is " + c);
    }
}
