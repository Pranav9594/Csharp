// ======================================================================
// Question No. : CD-P34
// Question     : Write a C# program to demonstrate an abstract class Animal with an abstract method and a normal method.
// Topic        : OOP - Abstract class
// File         : CD_p34_Abstract_Class_Animal.cs
// Source       : Codes.zip -> p34.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

abstract class Animal
{
    public abstract void animalSound();

    public void sleep()
    {
        Console.WriteLine("Zzz");
    }
}

class Pig : Animal
{
    public override void animalSound()
    {
        Console.WriteLine("The pig says: wee wee");
    }
}

class Dog : Animal
{
    public override void animalSound()
    {
        Console.WriteLine("The Dog says: bow boww");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Pig myPig = new Pig();  // Create a Pig object
        myPig.animalSound();
        myPig.sleep();
        Dog myDog = new Dog();  // Create a Dog object
        myDog.animalSound();
        myDog.sleep();

        Animal obj ;
        obj = myPig;
        obj.animalSound();
        obj.sleep();
        obj = myDog;
        obj.animalSound();
        obj.sleep();

    }
}
