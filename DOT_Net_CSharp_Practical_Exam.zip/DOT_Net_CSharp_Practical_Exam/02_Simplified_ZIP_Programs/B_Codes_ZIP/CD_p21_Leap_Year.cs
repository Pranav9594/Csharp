// ======================================================================
// Question No. : CD-P21
// Question     : Write a C# program to check whether a year is a leap year.
// Topic        : Date and time
// File         : CD_p21_Leap_Year.cs
// Source       : Codes.zip -> p21.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int year;

        Console.Write("Enter Year: ");
        year = int.Parse(Console.ReadLine());

        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
        {
            Console.WriteLine("Leap Year");
        }
        else
        {
            Console.WriteLine("Not a Leap Year");
        }
    }
}
