// ======================================================================
// Question No. : CD-P11
// Question     : Write a C# program to show that a do-while loop runs at least once.
// Topic        : Control statements
// File         : CD_p11_Do_While_Executes_Once.cs
// Source       : Codes.zip -> p11.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int i;
        i=11;
        do
        {
            Console.WriteLine (i);
            i++;
        }while (i<=10);
    }
}
