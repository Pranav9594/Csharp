// ======================================================================
// Question No. : CD-P46
// Question     : Write a C# program to create and throw a user defined exception.
// Topic        : Exception handling
// File         : CD_p46_Custom_Exception.cs
// Source       : Codes.zip -> p46.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

public class InvalidAgeException : Exception
{
    public InvalidAgeException(string message): base(message) {}
}

class Program {
    static void ValidateAge(int age) {
        if (age < 18){
            throw new InvalidAgeException("Age must be 18 or older to register.");
        }
        Console.WriteLine("Registration successful!");
    }
    static void Main(){
        try {
            ValidateAge(25);
        }
        catch (InvalidAgeException ex) {
            Console.WriteLine("Custom Exception:" + ex.Message);
        }
    }
}
