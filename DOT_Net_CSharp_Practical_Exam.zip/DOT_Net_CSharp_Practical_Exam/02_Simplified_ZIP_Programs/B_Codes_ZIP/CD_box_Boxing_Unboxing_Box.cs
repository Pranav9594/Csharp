// ======================================================================
// Question No. : CD-BOX
// Question     : Write a C# program to demonstrate boxing and unboxing.
// Topic        : Data types
// File         : CD_box_Boxing_Unboxing_Box.cs
// Source       : Codes.zip -> box.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main()
    {
        int x = 10;
        Object obj = x; //boxing
        Console.WriteLine(x);
        Console.WriteLine(obj);

        int y = (int)obj; //Unboxing
        Console.WriteLine(y);

    }
}
