// ======================================================================
// Question No. : CD-P09
// Question     : Write a C# program to show that a while loop may not execute at all.
// Topic        : Control statements
// File         : CD_p09_While_Loop_No_Output.cs
// Source       : Codes.zip -> p9.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int i;
        i=11;
        while (i<=10)
        {
            Console.WriteLine (i);
            i++;
        }
    }
}
