// ======================================================================
// Question No. : CD-P44
// Question     : Write a C# program to demonstrate try, multiple catch blocks and finally.
// Topic        : Exception handling
// File         : CD_p44_Try_Catch_Finally.cs
// Source       : Codes.zip -> p44.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int result=0;
        try
        {
            int[] myNumbers = {1, 2, 3};
            Console.WriteLine(myNumbers[1]);

            Console.Write("Enter first number: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter second number: ");
            int b = Convert.ToInt32(Console.ReadLine());

            result = a / b;
        }
        catch (DivideByZeroException ex)
        {
            Console.WriteLine("Error Occured " + ex.ToString());
        }
        catch ( FormatException ex) //Specific Exception Handler
        {
            Console.WriteLine("Error Occured " + ex.ToString());
        }

        finally
        {
            Console.WriteLine("In Finally Block");
        }

        Console.WriteLine("Result: " + result);

    }
}
