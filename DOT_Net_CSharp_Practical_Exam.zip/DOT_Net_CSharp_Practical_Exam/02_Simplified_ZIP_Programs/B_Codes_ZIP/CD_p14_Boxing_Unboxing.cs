// ======================================================================
// Question No. : CD-P14
// Question     : Write a C# program to demonstrate boxing and unboxing.
// Topic        : Data types
// File         : CD_p14_Boxing_Unboxing.cs
// Source       : Codes.zip -> p14.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main (String []ar)
    {
        int n = 10;
        object obj = n; // boxing
        Console.WriteLine (obj);
        int x  = (int)obj; // unboxing
        Console.WriteLine(x);
    }
}
