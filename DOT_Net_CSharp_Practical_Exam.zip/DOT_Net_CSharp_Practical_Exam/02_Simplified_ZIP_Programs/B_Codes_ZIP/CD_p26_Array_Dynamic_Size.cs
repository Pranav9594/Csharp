// ======================================================================
// Question No. : CD-P26
// Question     : Write a C# program to read the size of an array at run time, then read and display its elements.
// Topic        : Arrays
// File         : CD_p26_Array_Dynamic_Size.cs
// Source       : Codes.zip -> p26.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int n;
        Console.WriteLine("Enter Array Size ");
        n = Int32.Parse(Console.ReadLine());
        int [] a =  new int [n];
        int i;

        Console.WriteLine("Enter {0} Elements ",n);
        for (i=0;i<n;i++)
        {
            a[i] = Int32.Parse (Console.ReadLine());
        }
        Console.WriteLine("Given {0} Elements ",n);

        for (i=0;i<n;i++)
        {
            Console.WriteLine(a[i]);
        }
    }
}
