// ======================================================================
// Question No. : CD-P05
// Question     : Write a C# program using switch to display One, Two or Three for the numbers 1 to 3.
// Topic        : Control statements
// File         : CD_p05_Switch_One_Two_Three.cs
// Source       : Codes.zip -> p5.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int n;
        Console.WriteLine("Enter any Number between ( 1-3)  ");
        n = Int32.Parse(Console.ReadLine());
        switch (n)
        {
            case 1:
            Console.WriteLine ("One");
            break;
            case 2:
            Console.WriteLine ("Two");
            break;
            case 3:
            Console.WriteLine ("Three");
            break;
            default:
            Console.WriteLine ("Invalid Case");
            break;
        }
    }
}
