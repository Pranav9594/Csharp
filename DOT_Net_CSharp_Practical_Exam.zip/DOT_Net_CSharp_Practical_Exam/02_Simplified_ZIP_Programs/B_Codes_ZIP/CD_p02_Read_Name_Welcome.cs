// ======================================================================
// Question No. : CD-P02
// Question     : Write a C# program to read your name and display a welcome message.
// Topic        : Basics
// File         : CD_p02_Read_Name_Welcome.cs
// Source       : Codes.zip -> p2.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        String str;
        Console.WriteLine("Enter Your Name ");
        str = Console.ReadLine();
        Console.WriteLine ("Welcome " + str);
    }
}
