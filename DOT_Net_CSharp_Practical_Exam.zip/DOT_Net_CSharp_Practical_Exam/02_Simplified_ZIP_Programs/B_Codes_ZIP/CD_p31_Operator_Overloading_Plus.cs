// ======================================================================
// Question No. : CD-P31
// Question     : Write a C# program to overload the + operator.
// Topic        : OOP - Operator overloading
// File         : CD_p31_Operator_Overloading_Plus.cs
// Source       : Codes.zip -> p31.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    private int a,b;

    public Sample() //Default Constructor
    {
        a=0;
        b=0;
    }
    public Sample(int x,int y) //Default Constructor
    {
        a=x;
        b=y;
    }
    public void Display ()
    {
        Console.WriteLine (a + "   " + b);
    }

    public static Sample operator + (Sample X,Sample Y)
    {
        Sample Z = new Sample();
        Z.a = X.a + Y.a;
        Z.b = X.b + Y.b;
        return Z;
    }
}

class Test
{
    public static void Main ()
    {
        Sample S1 = new Sample(10,20);
        Sample S2 = new Sample(30,40);
        Console.WriteLine("Given Values ");
        S1.Display();
        S2.Display();
        Sample S3 = S1 + S2;
        Console.WriteLine ("Addition " );
        S3.Display();
    }
}
