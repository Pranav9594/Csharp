// ======================================================================
// Question No. : CD-P24
// Question     : Write a C# program to read a 3 x 3 matrix and display its transpose.
// Topic        : Arrays
// File         : CD_p24_Matrix_Transpose.cs
// Source       : Codes.zip -> p24.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int [,] arr =  new int [3,3];
        int i,j;

        Console.WriteLine("Enter 3 X 3 Matrix ");

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                arr[i,j] = Int32.Parse (Console.ReadLine());
            }
        }

        Console.WriteLine("Given 3 X 3 Matrix ");

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                Console.Write(arr[i,j] + "\t");
            }
            Console.WriteLine();
        }
        Console.WriteLine("Transpose of Given 3 X 3 Matrix ");

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                Console.Write(arr[j,i] + "\t");
            }
            Console.WriteLine();
        }

    }
}
