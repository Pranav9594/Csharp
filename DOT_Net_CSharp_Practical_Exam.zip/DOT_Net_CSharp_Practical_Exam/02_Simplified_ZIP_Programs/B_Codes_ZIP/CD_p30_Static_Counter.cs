// ======================================================================
// Question No. : CD-P30
// Question     : Write a C# program to demonstrate a static data member and static method.
// Topic        : OOP - static
// File         : CD_p30_Static_Counter.cs
// Source       : Codes.zip -> p30.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Counter
{
    public static int count;//class variable

    public Counter() //Default Constructor
    {
        count++;
    }
    public static void getCount ()
    {
        Console.WriteLine ("Count  " + count);
    }
}

class Sample
{
    public static void Main ()
    {
        Counter.count=10;
        Counter.getCount();
        Counter S1 = new Counter();
        Counter S2 = new Counter();
        Counter S3 = new Counter();
        Counter.getCount();
    }
}
