// ======================================================================
// Question No. : CD-THREADEX
// Question     : Write a C# program to implement threading concepts.
// Topic        : Multithreading
// File         : CD_threadex_Threading_Two_Threads.cs
// Source       : Codes.zip -> threadex.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

// C# Program to Demonstrate Multithreading

using System;
using System.Threading;

class MultiThreadDemo
{
    // Method for first thread
    public static void PrintNumbers()
    {
        for (int i = 1; i <= 5; i++)
        {
            Console.WriteLine("Number Thread: " + i);
            Thread.Sleep(500); // Pause for 500 milliseconds
        }
    }

    // Method for second thread
    public static void PrintCharacters()
    {
        for (char ch = 'A'; ch <= 'E'; ch++)
        {
            Console.WriteLine("Character Thread: " + ch);
            Thread.Sleep(500); // Pause for 500 milliseconds
        }
    }

    static void Main(string[] args)
    {
        // Creating threads
        Thread t1 = new Thread(PrintNumbers);
        Thread t2 = new Thread(PrintCharacters);

        // Starting threads
        t1.Start();
        t2.Start();

        // Wait for both threads to complete
        t1.Join();
        t2.Join();

        Console.WriteLine("Both threads have finished execution.");

    }
}
