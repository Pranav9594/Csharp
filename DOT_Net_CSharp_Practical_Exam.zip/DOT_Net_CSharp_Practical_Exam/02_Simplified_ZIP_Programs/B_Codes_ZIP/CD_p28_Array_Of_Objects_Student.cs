// ======================================================================
// Question No. : CD-P28
// Question     : Write a C# program to store details of 3 students using an array of objects.
// Topic        : OOP - Class
// File         : CD_p28_Array_Of_Objects_Student.cs
// Source       : Codes.zip -> p28.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Student
{
    private int rno;
    private String name;

    public void setData ()
    {
        Console.WriteLine ("Enter Roll No ");
        rno = Int32.Parse (Console.ReadLine());
        Console.WriteLine ("Enter Name ");
        name = Console.ReadLine();
    }

    public void putData ()
    {
        Console.WriteLine ("Roll No "+ rno);
        Console.WriteLine ("Name   " +name);
    }
}

class Sample
{
    public static void Main ()
    {
        Student []S = new Student[3]; //Array of Student References.
        for (int i=0;i<3;i++)
        {
            S[i] = new Student();
            S[i].setData();
        }
        for (int i=0;i<3;i++)
        {
            S[i].putData ();
        }
    }
}
