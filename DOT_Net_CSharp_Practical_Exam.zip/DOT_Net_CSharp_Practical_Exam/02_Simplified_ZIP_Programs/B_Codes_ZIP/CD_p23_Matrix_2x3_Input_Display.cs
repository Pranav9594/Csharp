// ======================================================================
// Question No. : CD-P23
// Question     : Write a C# program to read and display a 2 x 3 matrix.
// Topic        : Arrays
// File         : CD_p23_Matrix_2x3_Input_Display.cs
// Source       : Codes.zip -> p23.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int [,] arr =  new int [2,3];
        int i,j;

        Console.WriteLine("Enter 2 X 3 Matrix ");

        for (i=0;i<2;i++)
        {
            for (j=0;j<3;j++)
            {
                arr[i,j] = Int32.Parse (Console.ReadLine());
            }
        }

        Console.WriteLine("Given 2 X 3 Matrix ");

        for (i=0;i<2;i++)
        {
            for (j=0;j<3;j++)
            {
                Console.Write(arr[i,j] + "\t");
            }
            Console.WriteLine();
        }

    }
}
