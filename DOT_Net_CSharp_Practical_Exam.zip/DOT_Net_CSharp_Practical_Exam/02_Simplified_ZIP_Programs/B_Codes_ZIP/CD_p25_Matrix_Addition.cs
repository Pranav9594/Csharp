// ======================================================================
// Question No. : CD-P25
// Question     : Write a C# program to add two 3 x 3 matrices.
// Topic        : Arrays
// File         : CD_p25_Matrix_Addition.cs
// Source       : Codes.zip -> p25.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int [,] a =  new int [3,3];
        int [,] b =  new int [3,3];
        int [,] c =  new int [3,3];
        int i,j;

        Console.WriteLine("Enter First 3 X 3 Matrix ");

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                a[i,j] = Int32.Parse (Console.ReadLine());
            }
        }

        Console.WriteLine("Enter Second 3 X 3 Matrix ");

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                b[i,j] = Int32.Parse (Console.ReadLine());
            }
        }

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                c[i,j] = a[i,j] + b [i,j];
            }
        }

        Console.WriteLine("First  3 X 3 Matrix ");

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                Console.Write(a[i,j] + "\t");
            }
            Console.WriteLine();
        }
        Console.WriteLine("Second  3 X 3 Matrix ");

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                Console.Write(b[i,j] + "\t");
            }
            Console.WriteLine();
        }
        Console.WriteLine("Matrix Addition ");

        for (i=0;i<3;i++)
        {
            for (j=0;j<3;j++)
            {
                Console.Write(c[i,j] + "\t");
            }
            Console.WriteLine();
        }
    }
}
