// ======================================================================
// Question No. : CD-P03
// Question     : Write a C# program to perform all arithmetic operations on two numbers.
// Topic        : Operators
// File         : CD_p03_Arithmetic_Operations.cs
// Source       : Codes.zip -> p3.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int a,b,c;
        Console.WriteLine("Enter Two Numbers ");
        a = Int32.Parse(Console.ReadLine());
        b = Int32.Parse(Console.ReadLine());
        c = a + b;
        Console.WriteLine ("Addition " + c);
        c = a - b;
        Console.WriteLine ("Substraction " + c);
        c = a * b;
        Console.WriteLine ("Multiplication " + c);
        c = a / b;
        Console.WriteLine ("Division " + c);
        c = a % b;
        Console.WriteLine ("Remainder " + c);
    }
}
