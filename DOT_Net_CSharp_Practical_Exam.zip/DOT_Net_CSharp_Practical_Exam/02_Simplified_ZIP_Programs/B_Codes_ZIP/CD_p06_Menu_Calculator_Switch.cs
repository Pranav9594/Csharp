// ======================================================================
// Question No. : CD-P06
// Question     : Write a C# program for a menu driven calculator using switch.
// Topic        : Control statements
// File         : CD_p06_Menu_Calculator_Switch.cs
// Source       : Codes.zip -> p6.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    static void Main ()
    {
        int n;
        int a,b,c;
        Console.WriteLine("1.Addition");
        Console.WriteLine("2.Substraction");
        Console.WriteLine("3.Multiplication");
        Console.WriteLine("4.Division");
        Console.WriteLine("5.Remainder");
        Console.WriteLine ("Enter your Option " );
        n = Int32.Parse(Console.ReadLine());
        switch (n)
        {
            case 1:
            Console.WriteLine("Enter Two Numbers ");
            a = Int32.Parse(Console.ReadLine());
            b = Int32.Parse(Console.ReadLine());
            c = a + b;
            Console.WriteLine ("Addition " + c);
            break;
            case 2:
            Console.WriteLine("Enter Two Numbers ");
            a = Int32.Parse(Console.ReadLine());
            b = Int32.Parse(Console.ReadLine());
            c = a - b;
            Console.WriteLine ("Substraction " + c);
            break;
            case 3:
            Console.WriteLine("Enter Two Numbers ");
            a = Int32.Parse(Console.ReadLine());
            b = Int32.Parse(Console.ReadLine());
            c = a * b;
            Console.WriteLine ("Multiplication " + c);
            break;
            case 4:
            Console.WriteLine("Enter Two Numbers ");
            a = Int32.Parse(Console.ReadLine());
            b = Int32.Parse(Console.ReadLine());
            c = a / b;
            Console.WriteLine ("Division " + c);
            break;
            case 5:
            Console.WriteLine("Enter Two Numbers ");
            a = Int32.Parse(Console.ReadLine());
            b = Int32.Parse(Console.ReadLine());
            c = a % b;
            Console.WriteLine ("Remainder " + c);
            break;
            default:
            Console.WriteLine ("Invalid Case");
            break;
        }
    }
}
