// ======================================================================
// Question No. : CD-P33
// Question     : Write a C# program to demonstrate an abstract class with an abstract method.
// Topic        : OOP - Abstract class
// File         : CD_p33_Abstract_Class_Shape_Draw.cs
// Source       : Codes.zip -> p33.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

abstract class Shape
{
    abstract public void draw();
}

class Circle : Shape
{
    public override void draw()
    {
        Console.WriteLine ("Circle Draw");
    }
}

class Rect : Shape
{
    public override void draw()
    {
        Console.WriteLine ("Rectangle Draw");
    }
}

class Sample
{
    public static void Main ()
    {
        Shape S;//Reference
        Circle C = new Circle ();//object
        Rect R = new Rect();//object

        //Compile time Polymorphism
        C.draw();
        R.draw();

        //Runtime Polymorphism
        S = C;
        S.draw();
        S = R;
        S.draw();
    }
}
