// ======================================================================
// Question No. : CD-P36
// Question     : Demonstrate arrays of interface types (for runtime polymorphism) with a C# program.
// Topic        : OOP - Interface
// File         : CD_p36_Interface_Array_Shapes.cs
// Source       : Codes.zip -> p36.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

interface IShape
{
    double Area();

}
class Circle : IShape
{
    public double radius;

    public Circle(double r)
    {

        radius = r;
    }
    public double Area()
    {
        return Math.PI * radius * radius;
    }
}
class Rectangle : IShape
{
    public double length, breadth;

    public Rectangle(double l, double b)
    {
        length = l;
        breadth = b;
    }

    public double Area()
    {
        return length * breadth;
    }
}

class Program
{
    static void Main()
    {
        IShape[] shapes = new IShape[2];

        shapes[0] = new Circle(5);
        shapes[1] = new Rectangle(4, 6);

        foreach (IShape shape in shapes)
        {
            Console.WriteLine("Area: " + shape.Area());
        }
    }
}
