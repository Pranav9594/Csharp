﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace WindowsFormsApplication10
{
    public partial class Form1 : Form
    {
        SqlConnection cn;
        public Form1()
        {
            InitializeComponent();
            cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication10\WindowsFormsApplication10\Database1.mdf;Integrated Security=True;User Instance=True");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cn.Open();

            if (cn.State == ConnectionState.Open)
            {
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Employee values (@no,@nm)";
                cmd.Connection = cn;

                SqlParameter p1, p2;

                p1 = new SqlParameter();
                p1.ParameterName = "no";
                p1.Value = Int32.Parse(textBox1.Text);

                p2 = new SqlParameter();
                p2.ParameterName = "nm";
                p2.Value = textBox2.Text;

                cmd.Parameters.Add(p1);
                cmd.Parameters.Add(p2);

                cmd.ExecuteNonQuery();

                cn.Close();

                MessageBox.Show("Record Inserted Successfully");

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Employee", cn);
            DataSet ds = new DataSet();
            da.Fill(ds, "abc");
            DataTable dt = ds.Tables["abc"];
            dataGridView1.DataSource = dt;
            cn.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            cn.Open();
            if (cn.State == ConnectionState.Open)
            {

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update Employee set ename=@nm where empno=" + Int32.Parse(textBox1.Text);
                cmd.Connection = cn;
                SqlParameter p1;
                p1 = new SqlParameter();
                p1.ParameterName = "nm";               
                p1.Value = textBox2.Text;

                cmd.Parameters.Add(p1);
                cmd.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Record Updated Successfully");

            }
          

        }

        private void button3_Click(object sender, EventArgs e)
        {
            cn.Open();

            if (cn.State == ConnectionState.Open)
            {
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "Delete from Employee where empno=@x";
                cmd.Connection = cn;

                SqlParameter p1;

                p1 = new SqlParameter();
                p1.ParameterName = "x";
                p1.Value = Int32.Parse(textBox1.Text);

                cmd.Parameters.Add(p1);

                cmd.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Record Deleted Successfully");


            }
          

        }
    }
}
