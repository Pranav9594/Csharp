// ======================================================================
// Question No. : ADO-P01
// Question     : Write a C# program to connect to a SQL Server database and display whether the connection opened.
// Topic        : ADO.NET
// File         : ADO_p01_Connect_To_Database.cs
// Source       : Codes.zip / ado_netprograms -> p1.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;
        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication2\WindowsFormsApplication2\Database1.mdf;Integrated Security=True;User Instance=True");
        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {
            Console.WriteLine ("Connected ");
        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
