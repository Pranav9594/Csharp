// ======================================================================
// Question No. : ADO-P08
// Question     : Write a C# program to insert a record using SqlCommand with parameters.
// Topic        : ADO.NET
// File         : ADO_p08_Insert_Using_Parameters.cs
// Source       : Codes.zip / ado_netprograms -> p8.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;

        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication7\WindowsFormsApplication7\Database1.mdf;Integrated Security=True;User Instance=True");

        cn.Open();

        if ( cn.State==ConnectionState.Open)
        {
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "insert into Employee values (@no,@nm)";
            cmd.Connection = cn;

            SqlParameter p1,p2;

            p1 = new SqlParameter ();
            p1.ParameterName = "no";
            p1.Value = Int32.Parse (Console.ReadLine());

            p2 = new SqlParameter ();
            p2.ParameterName = "nm";
            p2.Value = Console.ReadLine();

            cmd.Parameters.Add (p1);
            cmd.Parameters.Add (p2);

            cmd.ExecuteNonQuery();

        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
