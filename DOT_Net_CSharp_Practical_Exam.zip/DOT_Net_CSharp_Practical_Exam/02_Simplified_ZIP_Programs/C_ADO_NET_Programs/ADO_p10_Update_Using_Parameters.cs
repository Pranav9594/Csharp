// ======================================================================
// Question No. : ADO-P10
// Question     : Write a C# program to update a record using SqlCommand with a parameter.
// Topic        : ADO.NET
// File         : ADO_p10_Update_Using_Parameters.cs
// Source       : Codes.zip / ado_netprograms -> p10.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;

        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication7\WindowsFormsApplication7\Database1.mdf;Integrated Security=True;User Instance=True");

        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {

            SqlCommand cmd = new SqlCommand();
            Console.WriteLine("Enter Emp.No ");
            cmd.CommandText = "Update Employee set ename=@nm where     empno=" + Int32.Parse(Console.ReadLine());
            cmd.Connection = cn;

            SqlParameter p1;

            p1 = new SqlParameter ();
            p1.ParameterName = "nm";
            Console.WriteLine("Enter Emp.Name ");
            p1.Value = Console.ReadLine();

            cmd.Parameters.Add(p1);
            cmd.ExecuteNonQuery();

        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
