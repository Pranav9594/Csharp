// ======================================================================
// Question No. : ADO-P12
// Question     : Write a C# program to call a stored procedure to add an employee.
// Topic        : ADO.NET
// File         : ADO_p12_Stored_Procedure.cs
// Source       : Codes.zip / ado_netprograms -> p12.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main()
    {
        SqlConnection cn;
        cn = new SqlConnection("Data Source=.;Initial Catalog=test;User ID=sa;Password=sa");
        cn.Open();
        if (cn.State == ConnectionState.Open)
        {
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "spAddEmployee";
            cmd.Connection = cn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", Int32.Parse(Console.ReadLine()));
            cmd.Parameters.AddWithValue("@nm", Console.ReadLine());
            cmd.Parameters.AddWithValue("@sal", Double.Parse(Console.ReadLine()));

            cmd.ExecuteNonQuery();

        }
        else
        {
            Console.WriteLine("Connection Failed ");
        }
        cn.Close();
    }
}
