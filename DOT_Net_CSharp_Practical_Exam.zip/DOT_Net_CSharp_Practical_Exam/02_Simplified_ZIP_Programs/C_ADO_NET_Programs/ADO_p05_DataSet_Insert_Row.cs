// ======================================================================
// Question No. : ADO-P05
// Question     : Write a C# program to insert a new row using DataSet and SqlDataAdapter.
// Topic        : ADO.NET
// File         : ADO_p05_DataSet_Insert_Row.cs
// Source       : Codes.zip / ado_netprograms -> p5.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;

        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\admin\Documents\Visual Studio 2010\Projects\WindowsFormsApplication1\WindowsFormsApplication1\Database1.mdf;Integrated Security=True;User Instance=True");

        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {
            Console.WriteLine ("Connected ");
            SqlDataAdapter da = new SqlDataAdapter ("Select * from Employee",cn);
            DataSet ds = new DataSet ();
            da.Fill (ds,"abc");
            DataTable dt = ds.Tables["abc"];
            Console.WriteLine ("Before Modification");
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }

            DataRow rw = dt.NewRow();
            rw[0] = 5;
            rw[1]="Sachin";
            rw[2]=44444;

            dt.Rows.Add(rw);

            SqlCommandBuilder cb = new SqlCommandBuilder (da);
            da.Update (ds,"abc");

            Console.WriteLine ("After Modification");
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }

        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
