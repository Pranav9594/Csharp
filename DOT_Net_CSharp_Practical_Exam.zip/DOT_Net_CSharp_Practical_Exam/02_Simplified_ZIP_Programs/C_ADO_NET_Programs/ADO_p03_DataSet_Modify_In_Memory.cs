// ======================================================================
// Question No. : ADO-P03
// Question     : Write a C# program to change a row in the DataSet (disconnected mode) without updating the database.
// Topic        : ADO.NET
// File         : ADO_p03_DataSet_Modify_In_Memory.cs
// Source       : Codes.zip / ado_netprograms -> p3.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;

        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication2\WindowsFormsApplication2\Database1.mdf;Integrated Security=True;User Instance=True");

        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {
            Console.WriteLine ("Connected ");
            SqlDataAdapter da = new SqlDataAdapter ("Select * from Employee",cn);
            DataSet ds = new DataSet ();
            da.Fill (ds,"abc");
            DataTable dt = ds.Tables["abc"];
            Console.WriteLine ("Before Modification");
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }

            DataRow rw = dt.Rows[0];
            rw[1]="Shah";
            rw[2]=46000;

            Console.WriteLine ("After Modification");
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }

        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
