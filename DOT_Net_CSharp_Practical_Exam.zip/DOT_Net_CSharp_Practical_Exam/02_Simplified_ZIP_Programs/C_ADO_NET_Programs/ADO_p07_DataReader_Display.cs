// ======================================================================
// Question No. : ADO-P07
// Question     : Write a C# program to display records using SqlDataReader.
// Topic        : ADO.NET
// File         : ADO_p07_DataReader_Display.cs
// Source       : Codes.zip / ado_netprograms -> p7.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;
        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication7\WindowsFormsApplication7\Database1.mdf;Integrated Security=True;User Instance=True");

        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * from Employee";
            cmd.Connection = cn;

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Console.WriteLine (dr[0] + "  " + dr[1] );
            }
        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
