// ======================================================================
// Question No. : ADO-P04
// Question     : Write a C# program to modify a row in the DataSet and save it to the database using SqlCommandBuilder.
// Topic        : ADO.NET
// File         : ADO_p04_DataSet_Update_Database.cs
// Source       : Codes.zip / ado_netprograms -> p4.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;
        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication2\WindowsFormsApplication2\Database1.mdf;Integrated Security=True;User Instance=True");

        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {
            Console.WriteLine ("Connected ");
            SqlDataAdapter da = new SqlDataAdapter ("Select * from Employee",cn);
            DataSet ds = new DataSet ();
            da.Fill (ds,"abc");
            DataTable dt = ds.Tables["abc"];
            Console.WriteLine ("Before Modification");
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }

            DataRow rw = dt.Rows[0];
            rw[1]="Alok Shah";
            rw[2]=60000;

            SqlCommandBuilder cb = new SqlCommandBuilder (da);
            da.Update (ds,"abc");

            Console.WriteLine ("After Modification");
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }

        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
