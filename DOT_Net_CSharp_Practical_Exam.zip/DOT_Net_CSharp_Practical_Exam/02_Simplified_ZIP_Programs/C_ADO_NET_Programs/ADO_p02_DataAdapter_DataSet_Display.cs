// ======================================================================
// Question No. : ADO-P02
// Question     : Write a C# program to display the Employee table using SqlDataAdapter and DataSet.
// Topic        : ADO.NET
// File         : ADO_p02_DataAdapter_DataSet_Display.cs
// Source       : Codes.zip / ado_netprograms -> p2.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;
        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication2\WindowsFormsApplication2\Database1.mdf;Integrated Security=True;User Instance=True");
        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {
            Console.WriteLine ("Connected ");
            SqlDataAdapter da = new SqlDataAdapter ("Select * from Employee",cn);
            DataSet ds = new DataSet ();
            da.Fill (ds,"abc");
            DataTable dt = ds.Tables["abc"];
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }
        }
        else
        {

            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
