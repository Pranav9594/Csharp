// ======================================================================
// Question No. : ADO-P11
// Question     : Write a C# program to display the number of employees using ExecuteScalar.
// Topic        : ADO.NET
// File         : ADO_p11_ExecuteScalar_Count.cs
// Source       : Codes.zip / ado_netprograms -> p11.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;

        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\admin\documents\visual studio 2010\Projects\WindowsFormsApplication7\WindowsFormsApplication7\Database1.mdf;Integrated Security=True;User Instance=True");

        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select  count(*) from Employee";
            cmd.Connection = cn;
            Console.WriteLine ("No.of Employees : " + cmd.ExecuteScalar ().ToString());

        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
