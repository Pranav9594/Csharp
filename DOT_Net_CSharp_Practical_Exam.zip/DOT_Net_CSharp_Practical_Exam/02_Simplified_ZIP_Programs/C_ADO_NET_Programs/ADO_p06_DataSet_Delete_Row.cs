// ======================================================================
// Question No. : ADO-P06
// Question     : Write a C# program to delete a row using DataSet and SqlDataAdapter.
// Topic        : ADO.NET
// File         : ADO_p06_DataSet_Delete_Row.cs
// Source       : Codes.zip / ado_netprograms -> p6.cs
// Requires    : SQL Server Express + a database with an Employee table;
//              change the connection string path to your own .mdf file.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
using System.Data;
using System.Data.SqlClient;

class AdoDemo
{
    public static void Main ( )
    {
        SqlConnection cn;

        cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\admin\Documents\Visual Studio 2010\Projects\WindowsFormsApplication1\WindowsFormsApplication1\Database1.mdf;Integrated Security=True;User Instance=True");

        cn.Open();
        if ( cn.State==ConnectionState.Open)
        {
            Console.WriteLine ("Connected ");
            SqlDataAdapter da = new SqlDataAdapter ("Select * from Employee",cn);
            DataSet ds = new DataSet ();
            da.Fill (ds,"abc");
            DataTable dt = ds.Tables["abc"];
            Console.WriteLine ("Before Modification");
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }
            Console.Write("Enter Empno to Delete :");
            DataRow rw = dt.Select("Emp_No =" + Console.ReadLine())[0];
            rw.Delete();

            SqlCommandBuilder cb = new SqlCommandBuilder (da);
            da.Update (ds,"abc");

            Console.WriteLine ("After Modification");
            foreach ( DataRow r in dt.Rows)
            {
                Console.WriteLine (r[0] + " " + r[1] + " " + r[2] );
            }

        }
        else
        {
            Console.WriteLine ("Connection Failed ");
        }
        cn.Close();
    }
}
