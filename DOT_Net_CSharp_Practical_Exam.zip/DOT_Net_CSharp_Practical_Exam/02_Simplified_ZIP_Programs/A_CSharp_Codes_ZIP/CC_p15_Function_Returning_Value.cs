// ======================================================================
// Question No. : CC-P15
// Question     : Write a C# program to define a method that returns the product of two numbers.
// Topic        : Methods
// File         : CC_p15_Function_Returning_Value.cs
// Source       : C# Codes.zip -> p15.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static int Multiply(int a, int b)
    {
        return a * b;
    }

    static void Main()
    {
        int result = Multiply(5, 4);
        Console.WriteLine(result);
    }
}
