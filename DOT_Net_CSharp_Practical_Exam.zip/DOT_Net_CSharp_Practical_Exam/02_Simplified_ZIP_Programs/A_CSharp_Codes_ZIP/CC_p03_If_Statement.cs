// ======================================================================
// Question No. : CC-P03
// Question     : Write a C# program to read a number and display a message if it is positive.
// Topic        : Control statements
// File         : CC_p03_If_Statement.cs
// Source       : C# Codes.zip -> p3.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class IfExample
{
    static void Main()
    {
        int num;

        Console.Write("Enter a number: ");
        num = Convert.ToInt32(Console.ReadLine());

        if (num > 0)
        {
            Console.WriteLine("The number is Positive");
        }
    }
}
