// ======================================================================
// Question No. : CC-P29
// Question     : Write a C# program to demonstrate hierarchical inheritance.
// Topic        : OOP - Inheritance
// File         : CC_p29_Hierarchical_Inheritance.cs
// Source       : C# Codes.zip -> p29.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public int x,y;
}
class B : A
{
    public int sum;

}
class C : A
{
    public int mul;
}
class Sample
{
    public static void Main ()
    {
        B obj1 = new B();
        Console.WriteLine ("Enter Two Numbers ");
        obj1.x = Int32.Parse(Console.ReadLine());
        obj1.y = Int32.Parse(Console.ReadLine());
        obj1.sum = obj1.x + obj1.y;
        Console.WriteLine("Addition " + obj1.sum );
        C obj2 = new C();
        Console.WriteLine ("Enter Two Numbers ");
        obj2.x = Int32.Parse(Console.ReadLine());
        obj2.y = Int32.Parse(Console.ReadLine());
        obj2.mul = obj2.x * obj2.y;
        Console.WriteLine("Multiplication " + obj2.mul );

    }
}
