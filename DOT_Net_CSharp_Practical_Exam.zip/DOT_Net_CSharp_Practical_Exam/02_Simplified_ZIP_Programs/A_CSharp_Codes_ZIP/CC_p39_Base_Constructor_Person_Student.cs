// ======================================================================
// Question No. : CC-P39
// Question     : Write a C# program to pass the name to the base class constructor of Person from Student.
// Topic        : OOP - Constructor in inheritance
// File         : CC_p39_Base_Constructor_Person_Student.cs
// Source       : C# Codes.zip -> p39.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Person {
    public string Name;

    public Person(string name) {
        Name = name;
    }
}
class Student : Person {
    public int RollNo;

    public Student(string name, int rollNo) : base(name)
    {
        RollNo = rollNo;
    }
    public void Display() {
        Console.WriteLine("Name: {0}, Roll No: {1}",Name,RollNo);
    }
}

class Program {
    static void Main() {
        Student student = new Student("Sudhir", 101);
        student.Display();
    }
}
