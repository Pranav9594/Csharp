// ======================================================================
// Question No. : CC-P20
// Question     : Write a C# program to demonstrate pass by value.
// Topic        : Parameters
// File         : CC_p20_Pass_By_Value.cs
// Source       : C# Codes.zip -> p20.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Change(int x)
    {
        x = 100;
    }

    static void Main()
    {
        int p = 10;
        Change ( p );
        Console.WriteLine(p);
    }
}
