// ======================================================================
// Question No. : CC-P31
// Question     : Write a C# program to show that a derived class Dog can use the method of its base class Animal.
// Topic        : OOP - Inheritance
// File         : CC_p31_Inheritance_Animal_Dog.cs
// Source       : C# Codes.zip -> p31.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Animal
{
    public void Eat()
    {
        Console.WriteLine("Animal is eating");
    }
}
class Dog : Animal
{
    public void Bark()
    {
        Console.WriteLine("Dog is barking");
    }
}

class Sample
{
    public static void Main ()
    {
        Dog d = new Dog();

        d.Eat();   // Inherited

        d.Bark();  // Own method

    }
}
