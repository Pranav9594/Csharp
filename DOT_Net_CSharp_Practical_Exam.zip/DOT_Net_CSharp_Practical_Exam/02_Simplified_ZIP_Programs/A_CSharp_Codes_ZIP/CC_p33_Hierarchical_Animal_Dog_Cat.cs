// ======================================================================
// Question No. : CC-P33
// Question     : Write a C# program for hierarchical inheritance using Animal, Dog and Cat.
// Topic        : OOP - Inheritance
// File         : CC_p33_Hierarchical_Animal_Dog_Cat.cs
// Source       : C# Codes.zip -> p33.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Animal
{
    public void Eat()
    {
        Console.WriteLine("Eating");
    }
}

class Dog : Animal
{
    public void Bark()
    {
        Console.WriteLine("Barking");
    }
}

class Cat : Animal
{
    public void Meow()
    {
        Console.WriteLine("Meowing");
    }
}

class Sample
{
    public static void Main ()
    {
        Dog d = new Dog();
        d.Eat();
        d.Bark();

        Cat c = new Cat();
        c.Eat();
        c.Meow();

    }
}
