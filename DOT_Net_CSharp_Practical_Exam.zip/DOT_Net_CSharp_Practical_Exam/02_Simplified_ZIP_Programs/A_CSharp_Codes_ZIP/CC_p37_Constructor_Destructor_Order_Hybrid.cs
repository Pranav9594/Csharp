// ======================================================================
// Question No. : CC-P37
// Question     : Write a C# program to show the order of constructors and destructors in hybrid inheritance.
// Topic        : OOP - Constructor in inheritance
// File         : CC_p37_Constructor_Destructor_Order_Hybrid.cs
// Source       : C# Codes.zip -> p37.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public A()
    {
        Console.WriteLine("A()");
    }

    ~A()
    {
        Console.WriteLine("~A()");
    }
}

class B : A
{
    public B()
    {
        Console.WriteLine("B()");
    }
    ~B()
    {
        Console.WriteLine("~B()");
    }
}

class C : B
{
    public C()
    {
        Console.WriteLine("C()");
    }
    ~C()
    {
        Console.WriteLine("~C()");
    }
}

class D : B
{
    public D()
    {
        Console.WriteLine("D()");
    }
    ~D()
    {
        Console.WriteLine("~D()");
    }
}

class Sample
{
    public static void Main ()
    {
        C obj1 = new C();
        D obj2 = new D();
    }
}
