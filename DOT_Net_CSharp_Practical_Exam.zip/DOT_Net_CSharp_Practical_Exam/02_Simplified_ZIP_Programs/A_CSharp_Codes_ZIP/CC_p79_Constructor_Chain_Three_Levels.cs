// ======================================================================
// Question No. : CC-P79
// Question     : Write a C# program using constructors with base() in a three level inheritance (A, B, C).
// Topic        : OOP - Constructor in inheritance
// File         : CC_p79_Constructor_Chain_Three_Levels.cs
// Source       : C# Codes.zip -> p79.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public int x;

    public A()
    {
        x=0;
    }

    public A(int p)
    {
        x = p;
    }
}

class B : A
{
    public int y;

    public B()
    {
        y=0;
    }
    public B(int p):base(p)
    {
        y = p;
    }
    public B(int p,int q):base(p)
    {
        y = q;
    }

}
class C : B
{
    public int sum;

    public C()
    {
        sum=0;
    }
    public C(int p):base(p)
    {
        sum=x+y;
    }
    public C(int p,int q):base(p,q)
    {
        sum = x+y;
    }

}

class Sample
{
    public static void Main ()
    {
        C obj1 = new C();
        Console.WriteLine ("Addition " + obj1.sum);
        C obj2 = new C(10);
        Console.WriteLine ("Addition " + obj2.sum);
        C obj3 = new C(10,20);
        Console.WriteLine ("Addition " + obj3.sum);

    }
}
