// ======================================================================
// Question No. : CC-P10
// Question     : Write a C# program to display a 2 x 3 matrix using a two dimensional array.
// Topic        : Arrays
// File         : CC_p10_Array_Two_Dimensional.cs
// Source       : C# Codes.zip -> p10.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int[,] matrix = {
            {1, 2, 3},
            {4, 5, 6}
        };
        for(int i = 0; i < 2; i++)
        {
            for(int j = 0; j < 3; j++)
            {
                Console.Write(matrix[i,j] + " ");
            }
            Console.WriteLine();
        }
    }
}
