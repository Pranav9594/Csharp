// ======================================================================
// Question No. : CC-P42
// Question     : Write a C# program to overload the + and - operators.
// Topic        : OOP - Operator overloading
// File         : CC_p42_Operator_Overloading_Plus_Minus.cs
// Source       : C# Codes.zip -> p42.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Sample
{
    private int a,b;

    public Sample() //Default Constructor
    {
        a=0;
        b=0;
    }
    public Sample(int x,int y) //Default Constructor
    {
        a=x;
        b=y;
    }
    public void Display ()
    {
        Console.WriteLine (a + "   " + b);
    }

    public static Sample operator + (Sample X,Sample Y)
    {
        Sample temp = new Sample();
        temp.a = X.a + Y.a;
        temp.b = X.b + Y.b;
        return temp;
    }
    public static Sample operator - (Sample X,Sample Y)
    {
        Sample temp = new Sample();
        temp.a = X.a - Y.a;
        temp.b = X.b - Y.b;
        return temp;
    }

}
class Test
{
    public static void Main ()
    {
        Sample S1 = new Sample(10,20);
        Sample S2 = new Sample(30,40);
        Console.WriteLine("Given Values ");
        S1.Display();
        S2.Display();
        Sample S3 = new Sample();
        S3 = S1 + S2;
        Console.WriteLine ("Addition " );
        S3.Display();
        S3 = S1 - S2;
        Console.WriteLine ("Substraction " );
        S3.Display();
    }
}
