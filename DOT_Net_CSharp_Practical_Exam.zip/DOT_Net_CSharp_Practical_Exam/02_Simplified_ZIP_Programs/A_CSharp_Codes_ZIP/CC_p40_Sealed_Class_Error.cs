// ======================================================================
// Question No. : CC-P40
// Question     : Write a C# program to show that a sealed class cannot be inherited.
// Topic        : OOP - sealed
// File         : CC_p40_Sealed_Class_Error.cs
// Source       : C# Codes.zip -> p40.cs
// Output       : compile error CS0509 is the expected result of this program.
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

sealed class FinalClass {
    public void Display() {
        Console.WriteLine("This is a sealed class.");
    }
}

class DerivedClass : FinalClass
{

}

class Sample
{
    public static void Main ()
    {
        DerivedClass obj = new DerivedClass();
    }
}
