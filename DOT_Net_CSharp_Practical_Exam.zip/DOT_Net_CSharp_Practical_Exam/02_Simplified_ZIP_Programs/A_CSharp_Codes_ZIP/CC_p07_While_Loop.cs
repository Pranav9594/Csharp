// ======================================================================
// Question No. : CC-P07
// Question     : Write a C# program to display numbers from 1 to 5 using a while loop.
// Topic        : Control statements
// File         : CC_p07_While_Loop.cs
// Source       : C# Codes.zip -> p7.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class WhileLoopExample
{
    static void Main()
    {
        int i = 1;

        while (i <= 5)
        {
            Console.WriteLine(i);
            i++;
        }
    }
}
