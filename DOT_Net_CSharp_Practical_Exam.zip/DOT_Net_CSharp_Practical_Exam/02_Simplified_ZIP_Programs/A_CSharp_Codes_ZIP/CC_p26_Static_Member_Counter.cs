// ======================================================================
// Question No. : CC-P26
// Question     : Write a C# program to count the objects created using a static variable.
// Topic        : OOP - static
// File         : CC_p26_Static_Member_Counter.cs
// Source       : C# Codes.zip -> p26.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Counter
{
    public  static int count = 0;

    public Counter()
    {
        count++;
    }
}

class Sample
{
    public static void Main ()
    {
        Console.WriteLine(Counter.count);
        Counter C1 = new Counter();
        Counter C2 = new Counter();
        Counter C3 = new Counter();
        Console.WriteLine(Counter.count);
    }
}
