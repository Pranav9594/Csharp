// ======================================================================
// Question No. : CC-P02
// Question     : Write a C# program to read two numbers and display their sum, difference, product, quotient and remainder.
// Topic        : Operators
// File         : CC_p02_Arithmetic_Operations.cs
// Source       : C# Codes.zip -> p2.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
class Program
{
    static void Main(string[] args)
    {
        int a,b,c;
        Console.WriteLine ("Enter Two Numbers ");
        a = Int32.Parse(Console.ReadLine());
        b = Int32.Parse(Console.ReadLine());
        c = a + b;
        Console.WriteLine ("Addition is " + c);
        c = a - b;
        Console.WriteLine ("Substraction is " + c);
        c = a * b;
        Console.WriteLine ("Multiplication is " + c);
        c = a / b;
        Console.WriteLine ("Division is " + c);
        c = a % b;
        Console.WriteLine ("Remainder is " + c);
    }
}
