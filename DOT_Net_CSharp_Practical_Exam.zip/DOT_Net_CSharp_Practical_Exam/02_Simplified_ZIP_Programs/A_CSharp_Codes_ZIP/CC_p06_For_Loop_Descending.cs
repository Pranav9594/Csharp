// ======================================================================
// Question No. : CC-P06
// Question     : Write a C# program to display numbers from 10 to 1 using a for loop.
// Topic        : Control statements
// File         : CC_p06_For_Loop_Descending.cs
// Source       : C# Codes.zip -> p6.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class ForLoopExample
{
    static void Main()
    {
        for (int i = 10; i >= 1; i--)
        {
            Console.WriteLine(i);
        }
    }
}
