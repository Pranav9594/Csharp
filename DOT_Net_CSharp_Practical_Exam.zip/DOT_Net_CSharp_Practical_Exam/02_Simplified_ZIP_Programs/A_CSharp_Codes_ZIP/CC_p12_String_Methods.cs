// ======================================================================
// Question No. : CC-P12
// Question     : Write a C# program to display the length of a string and convert it to upper and lower case.
// Topic        : Strings
// File         : CC_p12_String_Methods.cs
// Source       : C# Codes.zip -> p12.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        string text = "Hello World";
        Console.WriteLine(text.Length);
        Console.WriteLine(text.ToUpper());
        Console.WriteLine(text.ToLower());
    }
}
