// ======================================================================
// Question No. : CC-P11
// Question     : Write a C# program to create and display a jagged array.
// Topic        : Arrays
// File         : CC_p11_Array_Jagged.cs
// Source       : C# Codes.zip -> p11.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int[][] jagged = new int[3][];

        jagged[0] = new int[] {1,2};
        jagged[1] = new int[] {3,4,5};
        jagged[2] = new int[] {6,7,8,9};

        for(int i = 0; i < jagged.Length; i++)
        {
            for(int j = 0; j < jagged[i].Length; j++)
            {
                Console.Write(jagged[i][j] + " ");
            }
            Console.WriteLine();
        }
    }
}
