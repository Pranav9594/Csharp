// ======================================================================
// Question No. : CC-P17
// Question     : Write a C# program to display the square of a number using a method.
// Topic        : Methods
// File         : CC_p17_Function_Square.cs
// Source       : C# Codes.zip -> p17.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Square(int num)
    {
        Console.WriteLine(num * num);
    }

    static void Main()
    {
        Square(6);
    }
}
