// ======================================================================
// Question No. : CC-P04
// Question     : Write a C# program to check whether a number is even or odd.
// Topic        : Control statements
// File         : CC_p04_If_Else_Even_Odd.cs
// Source       : C# Codes.zip -> p4.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class IfElseExample
{
    static void Main()
    {
        int num;

        Console.Write("Enter a number: ");
        num = Convert.ToInt32(Console.ReadLine());

        if (num % 2 == 0)
        {
            Console.WriteLine("Number is Even");
        }
        else
        {
            Console.WriteLine("Number is Odd");
        }
    }
}
