// ======================================================================
// Question No. : CC-P27
// Question     : Write a C# program to demonstrate single inheritance.
// Topic        : OOP - Inheritance
// File         : CC_p27_Single_Inheritance.cs
// Source       : C# Codes.zip -> p27.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public int x;
}

class B : A
{
    public int y;

}

class Sample
{
    public static void Main ()
    {
        B obj = new B();
        Console.WriteLine ("Enter Two Numbers ");
        obj.x = Int32.Parse(Console.ReadLine());
        obj.y = Int32.Parse(Console.ReadLine());
        int sum = obj.x + obj.y;
        Console.WriteLine("Addition " + sum );
    }
}
