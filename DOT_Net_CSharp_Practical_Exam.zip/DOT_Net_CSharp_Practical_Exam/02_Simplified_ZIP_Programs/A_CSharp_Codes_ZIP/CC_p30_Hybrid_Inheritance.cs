// ======================================================================
// Question No. : CC-P30
// Question     : Write a C# program to demonstrate hybrid inheritance using classes.
// Topic        : OOP - Inheritance
// File         : CC_p30_Hybrid_Inheritance.cs
// Source       : C# Codes.zip -> p30.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public int x;
}
class B : A
{
    public int y;
}
class C : B
{
    public int sum;
}
class D : B
{
    public int mul;
}

class Sample
{
    public static void Main ()
    {
        C obj1 = new C();
        Console.WriteLine ("Enter Two Numbers ");
        obj1.x = Int32.Parse(Console.ReadLine());
        obj1.y = Int32.Parse(Console.ReadLine());
        obj1.sum = obj1.x + obj1.y;
        Console.WriteLine("Addition " + obj1.sum );
        D obj2 = new D();
        Console.WriteLine ("Enter Two Numbers ");
        obj2.x = Int32.Parse(Console.ReadLine());
        obj2.y = Int32.Parse(Console.ReadLine());
        obj2.mul = obj2.x * obj2.y;
        Console.WriteLine("Multiplication " + obj2.mul );
    }
}
