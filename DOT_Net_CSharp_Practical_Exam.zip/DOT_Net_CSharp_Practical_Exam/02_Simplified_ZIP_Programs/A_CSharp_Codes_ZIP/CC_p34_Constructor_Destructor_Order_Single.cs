// ======================================================================
// Question No. : CC-P34
// Question     : Write a C# program to show the order of constructors and destructors in single inheritance.
// Topic        : OOP - Constructor in inheritance
// File         : CC_p34_Constructor_Destructor_Order_Single.cs
// Source       : C# Codes.zip -> p34.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public A()
    {
        Console.WriteLine("A()");
    }

    ~A()
    {
        Console.WriteLine("~A()");
    }
}

class B : A
{
    public B()
    {
        Console.WriteLine("B()");
    }
    ~B()
    {
        Console.WriteLine("~B()");
    }
}

class Sample
{
    public static void Main ()
    {
        B obj = new B();
    }
}
