// ======================================================================
// Question No. : CC-P32
// Question     : Write a C# program for multilevel inheritance using Animal, Dog and Puppy.
// Topic        : OOP - Inheritance
// File         : CC_p32_Multilevel_Animal_Dog_Puppy.cs
// Source       : C# Codes.zip -> p32.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Animal
{
    public void Eat()
    {
        Console.WriteLine("Eating");
    }
}

class Dog : Animal
{
    public void Bark()
    {
        Console.WriteLine("Barking");
    }
}

class Puppy : Dog
{
    public void Weep()
    {
        Console.WriteLine("Weeping");
    }
}

class Sample
{
    public static void Main ()
    {
        Puppy p = new Puppy();

        p.Eat();   // From Animal

        p.Bark();  // From Dog

        p.Weep();  // Own
    }
}
