// ======================================================================
// Question No. : CC-P41
// Question     : Write a C# program to demonstrate method overloading.
// Topic        : OOP - Polymorphism
// File         : CC_p41_Method_Overloading.cs
// Source       : C# Codes.zip -> p41.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Printdata {

    void print(int i) {
        Console.WriteLine("Printing int: {0}", i );
    }

    void print(double f) {
        Console.WriteLine("Printing float: {0}" , f);
    }
    void print(string s) {
        Console.WriteLine("Printing string: {0}", s);
    }

    static void Main(string[] args) {
        Printdata p = new Printdata();

        // Call print to print integer
        p.print(5);

        // Call print to print float
        p.print(500.263);

        // Call print to print string
        p.print("Hello C++");

    }
}
