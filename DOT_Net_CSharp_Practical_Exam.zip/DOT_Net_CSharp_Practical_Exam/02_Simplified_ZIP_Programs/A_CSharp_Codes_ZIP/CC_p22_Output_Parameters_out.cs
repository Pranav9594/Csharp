// ======================================================================
// Question No. : CC-P22
// Question     : Write a C# program to demonstrate output parameters using the out keyword.
// Topic        : Parameters
// File         : CC_p22_Output_Parameters_out.cs
// Source       : C# Codes.zip -> p22.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Change(int x,int y,out int s,out int  m)
    {
        s = x+y;
        m = x * y;
    }

    static void Main()
    {
        int a = 10;
        int b = 20;
        int sum,mul;
        Change (a,b,out sum,out mul );
        Console.WriteLine("Addition "+ sum);
        Console.WriteLine("Multiplication "+ mul);

    }
}
