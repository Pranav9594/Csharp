// ======================================================================
// Question No. : CC-P21
// Question     : Write a C# program to demonstrate pass by reference using the ref keyword.
// Topic        : Parameters
// File         : CC_p21_Pass_By_Reference_ref.cs
// Source       : C# Codes.zip -> p21.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Change(ref int x)
    {
        x = 100;
    }

    static void Main()
    {
        int p = 10;
        Change ( ref p );
        Console.WriteLine(p);
    }
}
