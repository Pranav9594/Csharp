// ======================================================================
// Question No. : CC-P24
// Question     : Write a C# program to demonstrate a private data member accessed through public methods.
// Topic        : OOP - Class
// File         : CC_p24_Encapsulation_Private_Field.cs
// Source       : C# Codes.zip -> p24.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Account
{
    private double balance;

    public void Deposit(double amount)
    {
        balance += amount;
    }

    public double GetBalance()
    {
        return balance;
    }

}

class Sample
{
    public static void Main ()
    {
        Account obj = new Account();
        // obj.balance = 2000;   // ERROR in original: balance is private, so it cannot be used outside the class
        obj.Deposit(1000);
        Console.WriteLine("Current Balance " + obj.GetBalance());
        obj.Deposit(1000);
        Console.WriteLine("Current Balance " + obj.GetBalance());

    }
}
