// ======================================================================
// Question No. : CC-P36
// Question     : Write a C# program to show the order of constructors and destructors in hierarchical inheritance.
// Topic        : OOP - Constructor in inheritance
// File         : CC_p36_Constructor_Destructor_Order_Hierarchical.cs
// Source       : C# Codes.zip -> p36.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public A()
    {
        Console.WriteLine("A()");
    }

    ~A()
    {
        Console.WriteLine("~A()");
    }
}

class B : A
{
    public B()
    {
        Console.WriteLine("B()");
    }
    ~B()
    {
        Console.WriteLine("~B()");
    }
}

class C : A
{
    public C()
    {
        Console.WriteLine("C()");
    }
    ~C()
    {
        Console.WriteLine("~C()");
    }
}

class Sample
{
    public static void Main ()
    {
        B obj1 = new B();
        C obj2 = new C();
    }
}
