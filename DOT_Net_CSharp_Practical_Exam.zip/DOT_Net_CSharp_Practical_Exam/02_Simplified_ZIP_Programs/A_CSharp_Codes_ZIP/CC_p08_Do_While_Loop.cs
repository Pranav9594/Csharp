// ======================================================================
// Question No. : CC-P08
// Question     : Write a C# program to demonstrate the do-while loop.
// Topic        : Control statements
// File         : CC_p08_Do_While_Loop.cs
// Source       : C# Codes.zip -> p8.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class DoWhileExample
{
    static void Main()
    {
        int i = 10;

        do
        {
            Console.WriteLine(i);
            i++;
        }
        while (i <= 5);
    }
}
