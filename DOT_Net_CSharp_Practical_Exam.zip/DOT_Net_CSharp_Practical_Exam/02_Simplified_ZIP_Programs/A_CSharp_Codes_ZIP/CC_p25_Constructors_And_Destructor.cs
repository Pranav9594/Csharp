// ======================================================================
// Question No. : CC-P25
// Question     : Write a C# program to demonstrate default, parameterised and copy constructors and a destructor.
// Topic        : OOP - Constructor
// File         : CC_p25_Constructors_And_Destructor.cs
// Source       : C# Codes.zip -> p25.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Account
{
    private double balance;

    public Account() //default Constructor
    {
        balance = 500;
    }
    public Account(double x) //default Constructor
    {
        balance = x;
    }
    public Account(Account X) //Copy Constructor
    {
        balance = X.balance;
    }

    public void Deposit(double amount)
    {
        balance += amount;
    }

    public double GetBalance()
    {
        return balance;
    }

    ~Account() //destructor
    {
        Console.WriteLine("Object Destroyed");
    }

}

class Sample
{
    public static void Main ()
    {
        Account obj1 = new Account(5000);
        Console.WriteLine("Current Balance " + obj1.GetBalance());
        obj1.Deposit(1000);
        Console.WriteLine("Current Balance " + obj1.GetBalance());
        obj1.Deposit(1000);
        Console.WriteLine("Current Balance " + obj1.GetBalance());
        Account obj2 = new Account(obj1);
        Console.WriteLine("Current Balance " + obj2.GetBalance());
    }
}
