// ======================================================================
// Question No. : CC-P14
// Question     : Write a C# program to define a method that adds two numbers passed as parameters.
// Topic        : Methods
// File         : CC_p14_Function_With_Parameters.cs
// Source       : C# Codes.zip -> p14.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Add(int a, int b)
    {
        int sum = a + b;
        Console.WriteLine("Sum = " + sum);
    }

    static void Main()
    {
        Add(10, 20);
    }
}
