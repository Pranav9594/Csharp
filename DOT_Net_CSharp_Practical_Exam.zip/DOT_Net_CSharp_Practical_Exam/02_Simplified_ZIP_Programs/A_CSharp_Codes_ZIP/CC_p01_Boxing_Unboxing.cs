// ======================================================================
// Question No. : CC-P01
// Question     : Write a C# program to demonstrate boxing and unboxing.
// Topic        : Data types
// File         : CC_p01_Boxing_Unboxing.cs
// Source       : C# Codes.zip -> p1.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;
class Program
{
    static void Main(string[] args)
    {
        int n = 10;
        object obj = n;//boxing
        Console.WriteLine (obj);
        int x  = (int)obj; //Unboxing.
        Console.WriteLine (x);

    }
}
