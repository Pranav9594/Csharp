// ======================================================================
// Question No. : CC-P19
// Question     : Write a C# program to add two numbers using a method that returns the result.
// Topic        : Methods
// File         : CC_p19_Function_Add_Return.cs
// Source       : C# Codes.zip -> p19.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static int Add(int a, int b)
    {
        return a + b;
    }

    static void Main()
    {
        int result = Add(10, 15);
        Console.WriteLine(result);
    }
}
