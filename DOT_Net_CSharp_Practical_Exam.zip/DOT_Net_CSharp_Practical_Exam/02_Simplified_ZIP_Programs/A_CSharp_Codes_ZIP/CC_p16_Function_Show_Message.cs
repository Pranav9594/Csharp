// ======================================================================
// Question No. : CC-P16
// Question     : Write a C# program to call a method that displays "Hello".
// Topic        : Methods
// File         : CC_p16_Function_Show_Message.cs
// Source       : C# Codes.zip -> p16.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Show()
    {
        Console.WriteLine("Hello");
    }

    static void Main()
    {
        Show();
    }
}
