// ======================================================================
// Question No. : CC-P18
// Question     : Write a C# program to call a method that returns a fixed number.
// Topic        : Methods
// File         : CC_p18_Function_Get_Number.cs
// Source       : C# Codes.zip -> p18.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static int GetNumber()
    {
        return 100;
    }

    static void Main()
    {
        int n = GetNumber();
        Console.WriteLine(n);
    }
}
