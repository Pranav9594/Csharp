// ======================================================================
// Question No. : CC-P23
// Question     : Write a C# program to demonstrate variable length parameters using the params keyword.
// Topic        : Parameters
// File         : CC_p23_Variable_Length_Parameters_params.cs
// Source       : C# Codes.zip -> p23.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void test (params int [] x)
    {
        int sum = 0;
        for (int i=0;i<x.Length;i++)
        {
            sum = sum + x[i];
        }
        Console.WriteLine(sum);
    }

    static void Main()
    {
        test (10);
        test (10,20);
        test (10,20,30);
    }
}
