// ======================================================================
// Question No. : CC-P38
// Question     : Write a C# program to call base class constructors from a derived class using the base keyword.
// Topic        : OOP - Constructor in inheritance
// File         : CC_p38_Base_Keyword_Constructors.cs
// Source       : C# Codes.zip -> p38.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public int x;

    public A()
    {
        x=0;
    }

    public A(int p)
    {
        x = p;
    }
}

class B : A
{
    public int y;

    public B()
    {
        y=0;
    }
    public B(int p):base(p)
    {
        y = p;
    }
    public B(int p,int q):base(p)
    {
        y = q;
    }

}

class Sample
{
    public static void Main ()
    {
        B obj1 = new B();
        Console.WriteLine ("Addition " + (obj1.x+obj1.y));
        B obj2 = new B(10);
        Console.WriteLine ("Addition " + (obj2.x+obj2.y));
        B obj3 = new B(10,20);
        Console.WriteLine ("Addition " + (obj3.x+obj3.y));

    }
}
