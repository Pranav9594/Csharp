// ======================================================================
// Question No. : CC-P13
// Question     : Write a C# program to define and call a method with no parameters.
// Topic        : Methods
// File         : CC_p13_Function_Without_Parameters.cs
// Source       : C# Codes.zip -> p13.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void DisplayMessage() //function defination
    {
        Console.WriteLine("Welcome to C# Programming");
    }

    static void Main()
    {
        DisplayMessage(); //Function Call
    }
}
