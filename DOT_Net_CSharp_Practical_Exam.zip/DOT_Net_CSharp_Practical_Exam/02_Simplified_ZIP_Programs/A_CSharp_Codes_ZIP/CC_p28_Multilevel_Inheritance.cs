// ======================================================================
// Question No. : CC-P28
// Question     : Write a C# program to demonstrate multilevel inheritance.
// Topic        : OOP - Inheritance
// File         : CC_p28_Multilevel_Inheritance.cs
// Source       : C# Codes.zip -> p28.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class A
{
    public int x;
}
class B : A
{
    public int y;

}
class C : B
{
    public int sum;
}
class Sample
{
    public static void Main ()
    {
        C obj = new C();
        Console.WriteLine ("Enter Two Numbers ");
        obj.x = Int32.Parse(Console.ReadLine());
        obj.y = Int32.Parse(Console.ReadLine());
        obj.sum = obj.x + obj.y;
        Console.WriteLine("Addition " + obj.sum );
    }
}
