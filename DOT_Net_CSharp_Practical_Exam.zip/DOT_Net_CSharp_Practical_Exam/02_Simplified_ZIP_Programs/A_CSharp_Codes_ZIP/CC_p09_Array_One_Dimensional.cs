// ======================================================================
// Question No. : CC-P09
// Question     : Write a C# program to store five numbers in an array and display them.
// Topic        : Arrays
// File         : CC_p09_Array_One_Dimensional.cs
// Source       : C# Codes.zip -> p9.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class Program
{
    static void Main()
    {
        int[] numbers = new int[5];

        numbers[0] = 10;
        numbers[1] = 20;
        numbers[2] = 30;
        numbers[3] = 40;
        numbers[4] = 50;

        for(int i = 0; i < numbers.Length; i++)
        {
            Console.WriteLine(numbers[i]);
        }
    }
}
