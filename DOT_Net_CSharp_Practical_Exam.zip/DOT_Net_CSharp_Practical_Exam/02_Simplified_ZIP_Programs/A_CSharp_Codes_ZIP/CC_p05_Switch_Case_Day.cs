// ======================================================================
// Question No. : CC-P05
// Question     : Write a C# program using switch to display the day name for numbers 1 to 3.
// Topic        : Control statements
// File         : CC_p05_Switch_Case_Day.cs
// Source       : C# Codes.zip -> p5.cs
// Compatible   : Visual Studio 2010 / C# 4.0 / .NET Framework 4.0
// ======================================================================

using System;

class SwitchExample
{
    static void Main()
    {
        int day;

        Console.Write("Enter a number (1-3): ");
        day = Convert.ToInt32(Console.ReadLine());

        switch (day)
        {
            case 1:
            Console.WriteLine("Monday");
            break;

            case 2:
            Console.WriteLine("Tuesday");
            break;
            case 3:
            Console.WriteLine("Wednesday");
            break;

            default:
            Console.WriteLine("Invalid Input");
            break;
        }
    }
}
